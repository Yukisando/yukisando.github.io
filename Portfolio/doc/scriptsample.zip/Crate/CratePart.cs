﻿using UnityEngine;

public class CratePart : MonoBehaviour
{
    public bool fall;
    public float speed = 2;

    private Rigidbody2D m_rb;
    private ItemCatcher m_itemCatcher;
    private MeshRenderer m_meshRenderer;
    private ParticleSystemRenderer m_psRenderer;
    [SerializeField] private Texture normal, health;

    private Vector3 m_target;
    private bool m_isHealth;

    private void Awake()
    {
        m_target = GameObject.FindGameObjectWithTag("ItemCatcher").transform.position;
        m_itemCatcher = FindObjectOfType<ItemCatcher>();
        m_meshRenderer = GetComponent<MeshRenderer>();
        m_psRenderer = GetComponentInChildren<ParticleSystemRenderer>();
        m_rb = GetComponent<Rigidbody2D>();
        
        gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        Reset();
        Invoke(nameof(Fall), .3f);
    }

    private void Reset()
    {
        fall = false;
        m_rb.velocity = Vector3.zero;
        m_rb.gravityScale = 2;
        m_rb.mass = 3;
    }

    private void FixedUpdate()
    {
        //Adds gravity to the Crate parts for a small time before making them kinematic and send them towards the container
        if (!fall) return;
        var step = speed * Time.fixedDeltaTime; // calculate distance to move
        transform.position = Vector3.MoveTowards(transform.position, m_target, step);
        if (Vector3.Distance(transform.position, m_target) < .1f)
        {
            m_itemCatcher.Add();
            gameObject.SetActive(false);
        }

        if (Vector3.Distance(transform.position, m_target) < 0.001f) gameObject.SetActive(false);
    }

    //TODO: Set green texture for particle system
    public void SetAsHealth()
    {
        m_meshRenderer.material.mainTexture = health;
        if(m_psRenderer) m_psRenderer.material.mainTexture = health;
        m_rb.gravityScale = 1;
        m_rb.mass = 1;
    }


    private void Fall()
    {
        fall = true;
        m_rb.velocity = Vector3.zero;
        m_rb.mass = 1;
        m_rb.gravityScale = 0;
    }

    private void OnDisable()
    {
        transform.position = Vector3.zero;
        m_meshRenderer.material.mainTexture = normal;
        if(m_psRenderer) m_psRenderer.sharedMaterial.mainTexture = normal;
    }
}