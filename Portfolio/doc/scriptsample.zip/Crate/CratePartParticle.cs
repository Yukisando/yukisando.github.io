﻿using System;
using System.Collections;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public class CratePartParticle : MonoBehaviour
{
    [SerializeField] private float waitBeforeSuck = .6f;

    private ParticleSystem m_ps;
    private ParticleSystem.Particle[] m_particles;
    private ParticleSystem.MainModule m_psMain;
    private ParticleSystem.Burst m_burst;

    private Vector3 m_worldDestination;
    [SerializeField] private float suckSpeed = 3;

    private void Awake()
    {
        m_ps = GetComponent<ParticleSystem>();
        m_burst = new ParticleSystem.Burst();
        m_psMain = m_ps.main;
        m_particles = new ParticleSystem.Particle[m_psMain.maxParticles];
        m_worldDestination = FindObjectOfType<ItemCatcher>().GetComponent<RectTransform>().transform.position + new Vector3(.15f,.15f,0);
    }

    public void SpawnParticles()
    {
        m_ps.Play();
        gameObject.transform.SetParent(GameManager.Current.particles);
        StartCoroutine(Suck());
    }

    private IEnumerator Suck()
    {
        yield return new WaitForSeconds(waitBeforeSuck);

        var numParticlesAlive = m_ps.GetParticles(m_particles);
        m_psMain.gravityModifierMultiplier = 0.0f;

        while (numParticlesAlive > 0)
        {
            numParticlesAlive = m_ps.GetParticles(m_particles);

            // Change only the particles that are alive
            for (var i = 0; i < numParticlesAlive; i++)
            {
                m_particles[i].position = Vector3.Lerp(m_particles[i].position, m_worldDestination, Time.deltaTime * suckSpeed);
                if (Vector3.Distance(m_particles[i].position, m_worldDestination) < .2f) m_particles[i].remainingLifetime = -1;
            }

            // Apply the particle changes to the Particle System
            m_ps.SetParticles(m_particles, numParticlesAlive);
            yield return new WaitForEndOfFrame();
        }
    }

    public void SetCount(int _count)
    {
        m_burst.count = _count;
    }
}