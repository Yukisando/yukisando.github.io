﻿using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

public class Crate : MonoBehaviour
{

    public GameObject burningOverlay, frozenOverlay, electricOverlay, damagedOverlay;

    [SerializeField]
    private int health = 10;
    public GameObject damagePopupPrefab;
    public Sprite[] sprites;

    private bool m_init = true;
    private bool m_isFrozen, m_isBurning, m_isElectrified;
    private Rigidbody2D m_rb;

    private SpriteRenderer m_sr;
    private int m_startHealth = 10;
    private Vector3 m_initPosition;
    private Vector3 m_initScale;

    private void Awake()
    {
        m_sr = GetComponent<SpriteRenderer>();
        m_rb = GetComponent<Rigidbody2D>();

        //Chooses a random sprite
        m_sr.sprite = sprites[Random.Range(0, sprites.Length)];
        var T = transform;
        m_initPosition = T.position;
        m_initScale = T.localScale;

        gameObject.SetActive(false);
    }

    public void Reset()
    {
        electricOverlay.SetActive(false);
        burningOverlay.SetActive(false);
        frozenOverlay.SetActive(false);
        m_rb.velocity = Vector2.zero;
        m_rb.AddForce(Vector3.down * CrateSpawner.Current.initialForce, ForceMode2D.Impulse);
    }

    private void OnEnable()
    {
        var T = transform;
        T.position = m_initPosition;
        T.localScale = m_initScale;
        health = CrateSpawner.Current.crateHealth;
        m_startHealth = health;

        m_isFrozen = false;
        m_isElectrified = false;
        m_isBurning = false;

        //Sets a random size
        transform.localScale *= Random.Range(0.5f, 1.1f);
        CrateSpawner.Current.currentCrateCount++;
    }

    private void OnDisable()
    {
        StopAllCoroutines();
        if (!m_init)
            CrateSpawner.Current.currentCrateCount--;
        m_init = false;
    }

    private void Hit()
    {
        GameManager.Current.score += 2;
        health -= Cannon.Current.damage;
        var T = transform;
        T.localScale -= T.localScale / 20;
        AudioManager.Current.PlayCrateHit();

        //Destroys the crate if it gets too small (For gameplay reasons, and adds an element of randomness to the difficulty)
        if (transform.localScale.x <= .35f) health = 0;
        if (health <= 0)
        {
            AudioManager.Current.PlayCrateBreak();
            Instantiate(Assets.Current.crateBreak, transform.position, Quaternion.identity, GameManager.Current.particles);

            for (var i = 0; i < Random.Range(1, 8); i++)
            {
                var cp = CratePartPool.Current.Get(false);
                var transform1 = cp.transform;
                transform1.position = transform.position += (Vector3) Random.insideUnitCircle * .4f;
                transform1.rotation = Random.rotation;
                cp.gameObject.SetActive(true);
            }

            gameObject.SetActive(false);
        }

        //Sets the broken sprite overlay at half life
        if (health < m_startHealth / 2 && !damagedOverlay.activeSelf) damagedOverlay.SetActive(true);
    }

    //Freezes the rigidbody on the object for a short time
    //Crates move also slower after being frozen
    private IEnumerator Frozen()
    {
        frozenOverlay.SetActive(true);
        m_isFrozen = true;
        m_rb.velocity /= 5;
        yield return new WaitForSeconds(.8f + Cannon.Current.freeze / 5f);
        m_isFrozen = false;
        frozenOverlay.SetActive(false);
    }

    //Generate AOE damage to all crates in the blast radius
    private IEnumerator Electrified()
    {
        electricOverlay.SetActive(true);
        m_isElectrified = true;
        yield return new WaitForSeconds(.2f);
        electricOverlay.SetActive(false);
        var objInRadius = Physics2D.OverlapCircleAll(transform.position, 1.5f + Cannon.Current.electrify / 8f);
        foreach (var currentCrate in objInRadius.Where(_currentCrate => _currentCrate.GetComponent<Crate>() != null))
        {
            if (currentCrate.gameObject == gameObject) continue;
            var crate = currentCrate.GetComponent<Crate>();
            crate.health -= 3 + Cannon.Current.electrify;
            crate.Hit();
        }

        m_isElectrified = false;
    }

    //Adds an immediate burn damage and slow DOT
    private IEnumerator Burning()
    {
        burningOverlay.SetActive(true);
        m_isBurning = true;
        yield return new WaitForSeconds(.4f);
        health--;
        yield return new WaitForSeconds(.4f);
        health -= Cannon.Current.blaze;
        m_isBurning = false;
        burningOverlay.SetActive(false);
    }

    //Visual feedback from effects
    public void CollidedWithBall(Ball _ball)
    {
        var T = transform;
        switch (_ball.tag)
        {
            default:
                Hit();
                break;
            case "FrozenBall":
                Hit();
                GameManager.Current.score += 2;
                T.localScale -= T.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                if (gameObject.activeSelf && !m_isFrozen && !m_isBurning && !m_isElectrified) StartCoroutine(Frozen());
                break;

            case "ElectricBall":
                Hit();
                GameManager.Current.score += 2;
                T.localScale -= T.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                if (gameObject.activeSelf && !m_isElectrified && !m_isBurning && !m_isFrozen) StartCoroutine(Electrified());
                break;

            case "FireBall":
                Hit();
                GameManager.Current.score += 2;
                T.localScale -= T.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                if (gameObject.activeSelf && !m_isFrozen && !m_isBurning && !m_isElectrified) StartCoroutine(Burning());
                break;

            case "SideBall":
                Hit();
                GameManager.Current.score++;
                health -= 2 + CrateSpawner.Current.waveNumber / 4;
                T.localScale -= T.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                break;

            case "TurretBall":
                Hit();
                GameManager.Current.score++;
                health -= Turret.GetDamage();
                T.localScale -= T.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                break;
        }
    }

    private void OnTriggerEnter2D(Collider2D _other)
    {
        //Deals damage if the crates hits the bottom
        if (_other.CompareTag("Deadzone"))
        {
            GameManager.Current.DealDamageToPlayer(health);
            AudioManager.Current.PlayCrateFail();

            //Damage popup visual!
            var healthPopup = Instantiate(damagePopupPrefab, Vector3.zero, Quaternion.identity, GameManager.Current.particles).GetComponent<DamagePopup>();
            healthPopup.SetPosition(transform.position);
            healthPopup.SetHealthLossText(health.ToString());
            gameObject.SetActive(false);
        }

        //Piercing system implemented but not yet in use
        if (_other.CompareTag("TurretBall"))
        {
            GameManager.Current.score++;
            health -= Turret.GetDamage();
            transform.localScale -= transform.localScale / 25;
            AudioManager.Current.PlayCrateHit();
        }
    }

    private void OnBecameInvisible()
    {
        gameObject.SetActive(false);
    }

    private void OnDrawGizmos()
    {
        if (!m_isElectrified) return;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, 2f);
    }

}