﻿using System;
using UnityEngine;
using TMPro;

public class DamagePopup : MonoBehaviour
{

    private TextMeshPro m_healthLossText;
    private RectTransform m_rectTransform;

    private void Awake()
    {
        m_healthLossText = GetComponent<TextMeshPro>();
        m_rectTransform = GetComponent<RectTransform>();
        Destroy(gameObject, 2f);
    }

    public void SetHealthLossText(string _health)
    {
        m_healthLossText.text = _health;
    }

    public void SetPosition(Vector3 _position)
    {
        m_rectTransform.anchoredPosition = _position;
    }

}