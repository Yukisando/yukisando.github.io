﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CratePartPool : MonoBehaviour
{
    public static CratePartPool Current;

    [SerializeField] private CratePart cratePartPrefab;

    private List<CratePart> m_pool = new List<CratePart>();

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
    }

    private void Start()
    {
        //Pre-warms
        AddCratePart(30);
    }

    private void AddCratePart(int _amount)
    {
        for (var i = 0; i < _amount; i++)
        {
            var newCratePart = Instantiate(cratePartPrefab, GameManager.Current.items).GetComponent<CratePart>();
            newCratePart.gameObject.SetActive(false);
            m_pool.Add(newCratePart);
        }
    }

    public CratePart Get(bool _isHealth)
    {
        if (m_pool.Count == 0) AddCratePart(10);

        foreach (var cp in m_pool.Where(_cp => !_cp.gameObject.activeSelf))
        {
            if (_isHealth) cp.SetAsHealth();
            return cp;
        }


        //No available balls were found, extending the pool and returning the first
        var cpFromExtendedPool = Instantiate(cratePartPrefab, GameManager.Current.balls);
        cpFromExtendedPool.gameObject.SetActive(false);
        m_pool.Add(cpFromExtendedPool);

        AddCratePart(10);

        if (_isHealth) cpFromExtendedPool.SetAsHealth();
        return cpFromExtendedPool;
    }
}