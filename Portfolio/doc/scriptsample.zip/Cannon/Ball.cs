﻿using System;
using UnityEngine;
using UnityEngine.Experimental.Rendering.LWRP;

public class Ball : MonoBehaviour
{
    private Vector3 m_awakeSize;

    //Sets sprite on ball status
    public Sprite ballSprite, sideBallSprite, frozenSprite, fireSprite, electricSprite;

    //Keeps track of bounces
    private int m_bounces;
    public Color electricLightColor;
    public Color fireLightColor;
    public Color frozenLightColor;

    //Trails for related status
    public GameObject frozenTrail, fireTrail, electricTrail;
    private bool m_isBurst;

    //Ball's individual life time
    public Light2D lightEffect;

    [HideInInspector] public Rigidbody2D rigidBody;
    private float m_rotationIndex;
    private SpriteRenderer m_spriteRenderer;

    private void Awake()
    {
        m_spriteRenderer = GetComponent<SpriteRenderer>();
        rigidBody = GetComponent<Rigidbody2D>();

        m_awakeSize = transform.localScale;

        //Turns on light effects for night scenes
        if (GameManager.Current.nightScene)
        {
            lightEffect.enabled = true;
            lightEffect.color = Color.black;
        }

        gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        //Shoot the ball
        transform.position = Cannon.Current.nozzle.transform.position;
        rigidBody.velocity = Vector3.zero;
        rigidBody.AddTorque(5f, ForceMode2D.Impulse);

        //Sets the tag depending on status:
        //Crates will respond differently according to their tags
        switch (tag)
        {
            default: break;
            case "FrozenBall":
                if (GameManager.Current.nightScene) lightEffect.color = frozenLightColor;
                frozenTrail.SetActive(true);
                m_spriteRenderer.sprite = frozenSprite;
                break;
            case "FireBall":
                if (GameManager.Current.nightScene) lightEffect.color = fireLightColor;
                fireTrail.SetActive(true);
                m_spriteRenderer.sprite = fireSprite;
                break;
            case "ElectricBall":
                if (GameManager.Current.nightScene) lightEffect.color = electricLightColor;
                electricTrail.SetActive(true);
                m_spriteRenderer.sprite = electricSprite;
                break;
        }
    }

    public void SetAsNormal()
    {
        m_isBurst = false;
        tag = "Ball";
        m_spriteRenderer.sprite = ballSprite;
        transform.localScale = m_awakeSize + new Vector3(Cannon.Current.ballSizeIncrease, Cannon.Current.ballSizeIncrease, 0);
    }

    public void SetAsBurst()
    {
        m_isBurst = true;
        tag = "SideBall";
        m_spriteRenderer.sprite = sideBallSprite;
        transform.localScale = m_awakeSize + new Vector3(Cannon.Current.ballSizeIncrease / 2, Cannon.Current.ballSizeIncrease / 2, 0);
    }

    private void OnCollisionEnter2D(Collision2D _collider)
    {
        //Instantiates the appropriate particle on hit and sound effect
        var isCrate = _collider.gameObject.CompareTag("Crate");
        var isWall = _collider.gameObject.CompareTag("Wall");

        if (!isCrate && !isWall) return;

        if (isCrate) _collider.gameObject.GetComponent<Crate>().CollidedWithBall(this);

        SetBallEffect(_collider);

        //Count the bounce
        m_bounces++;
        if (m_bounces > Cannon.Current.bounceLimit || Cannon.Current.bounceLimit == 0) gameObject.SetActive(false);
    }

    private void SetBallEffect(Collision2D _other)
    {
        switch (tag)
        {
            case "FrozenBall":
                Instantiate(Assets.Current.freezeTouch, _other.contacts[0].point, Quaternion.identity, GameManager.Current.particles);
                AudioManager.Current.PlayFrozenCrateHit();
                break;
            case "ElectricBall":
                var electricityRadius = 1.5f + Cannon.Current.electrify / 5f;
                var electricTouch = Instantiate(Assets.Current.electricTouch, _other.contacts[0].point, Quaternion.identity, GameManager.Current.particles);
                electricTouch.transform.localScale = new Vector3(electricityRadius, electricityRadius, electricityRadius);
                AudioManager.Current.PlayElectricCrateHit();
                break;
            case "FireBall":
                Instantiate(Assets.Current.fireTouch, _other.contacts[0].point, Quaternion.identity, GameManager.Current.particles);
                AudioManager.Current.PlayBlazeCrateHit();
                break;
            default:
                Instantiate(Assets.Current.ballTouch, _other.contacts[0].point, Quaternion.identity, GameManager.Current.particles);
                AudioManager.Current.PlayWallHit();
                break;
        }
        
        if(m_isBurst) gameObject.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D _other)
    {
        if (_other.CompareTag("Balldump")) gameObject.SetActive(false);
    }

    private void OnBecameInvisible()
    {
        gameObject.SetActive(false);
    }

    private void OnDisable()
    {
        m_bounces = 0;
        tag = "Ball";
        frozenTrail.SetActive(false);
        fireTrail.SetActive(false);
        electricTrail.SetActive(false);
    }
}