﻿using UnityEngine;

public class FollowMouse : MonoBehaviour
{

    private Quaternion m_cannonAngle;
    public Vector3 offset = new Vector3(0, 0, -90);

    //Simply makes sure the cannon follows the mouse/finger
    //Some minor improvements are possible here. Maybe a circular slider ?
    private void Update()
    {
        Follow();
    }

    private void Follow()
    {
        var direction = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        var angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        m_cannonAngle = Quaternion.AngleAxis(angle, Vector3.forward) * Quaternion.Euler(offset);
        transform.rotation = m_cannonAngle;
    }

}