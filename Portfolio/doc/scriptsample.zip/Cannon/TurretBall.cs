﻿using UnityEngine;

public class TurretBall : MonoBehaviour
{

    private int m_hits;

    private void Awake()
    {
        m_hits = 0;
        if (Turret.Current.piercing > 0) GetComponent<Collider2D>().isTrigger = true;
    }

    private void Start()
    {
        Destroy(gameObject, 2f);
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D _other)
    {
        if (_other.CompareTag("Balldump")) Destroy(gameObject);

        if (Turret.Current.piercing > 0)
        {
            if (_other.gameObject.CompareTag("Crate"))
            {
                m_hits++;
                Instantiate(Assets.Current.ballTouch, _other.transform.position, Quaternion.identity, GameManager.Current.particles);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        if (m_hits > Turret.Current.piercing) Destroy(gameObject);
    }

    private void OnCollisionEnter2D(Collision2D _other)
    {
        if (Turret.Current.piercing != 0) return;
        
        if (_other.gameObject.CompareTag("Crate"))
        {
            Instantiate(Assets.Current.ballTouch, _other.contacts[0].point, Quaternion.identity, GameManager.Current.particles);
            Destroy(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

}