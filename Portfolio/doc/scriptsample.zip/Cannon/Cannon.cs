﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using UnityEngine;

public class Cannon : MonoBehaviour
{
    //Singleton
    public static Cannon Current;

    [SerializeField] private Ball ballPrefab;
    private List<Ball> m_ballPool = new List<Ball>();
    private Vector3 m_ballZOffset = new Vector3(0, 0, -1);
    private Coroutine m_shooting;
    private int m_shotCount;

    [Header("Details")] [SerializeField] private Vector3 burstAngleOffset = new Vector3(.1f, 0, 0);
    [SerializeField] private Vector3 burstPositionOffset = new Vector3(.3f, 0, 0);

    [Header("Player")] public int health = 100;
    public int damage = 1;
    public bool dead;

    [Header("Power Ups")] public int freeze;
    public int freezeCap = 15;

    public int electrify;
    public int electrifyCap = 18;

    public int blaze;
    public int blazeCap = 20;

    public float fireRate = 5f;
    public float fireRateCap = 20;

    public int bounceLimit = 1;
    public int bounceLimitCap = 5;

    public float ballSizeIncrease = 0.05f;
    public float sizeCap = .5f;

    public int countLimit = 20;
    public int countLimitCap = 30;

    private int m_burstCount;
    public int burst;
    public int burstCap = 10;

    private bool m_isShooting;
    public Transform nozzle;

    public float power = .2f;
    public float powerCap = 1.2f;

    [Header("Assignments")] public Sprite[] sprites;
    public SpriteRenderer sr;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
        dead = false;
    }

    private void Start()
    {
        //Pre-warms the pool
        CreateBalls(20);
    }

    private void Update()
    {
        FireStatus();
    }

    private float m_timer;

    private void FireStatus()
    {
        if (GameManager.Current.upgradeScreen.activeSelf || GameManager.Current.gameOverScreen.activeSelf) return;
        m_timer += Time.deltaTime;
        if (!(m_timer >= 1 / fireRate)) return;
        m_timer = 0;
        Shoot();
    }

    private void Shoot()
    {
        //A little inefficient but works for now
        var ballCount = m_ballPool.Count(_b => _b.gameObject.activeSelf);

        if (ballCount > countLimit) return;
        
        //Normal balls
        HandleNormal();

        //Burst Upgrade (1 enables it, more upgrades firerate, once the firerate == ball firerate enables bounce)
        if (burst > 0) HandleBurst();

        //Handles the cannon's visual feedback
        sr.sprite = sprites[1];
        Invoke(nameof(CannonBarrelReset), .1f);
    }

    private void HandleNormal()
    {
        var currentBall = GetBall();
        currentBall.SetAsNormal();

        m_shotCount++;

        //Handles the frequency of the status balls and grantees no overlap
        if (freeze > 0 && m_shotCount % 3 == 0) currentBall.tag = "FrozenBall";
        if (blaze > 0 && m_shotCount % 2 == 0) currentBall.tag = "FireBall";
        if (electrify > 0 && m_shotCount % 5 == 0) currentBall.tag = "ElectricBall";

        currentBall.gameObject.SetActive(true);
        currentBall.rigidBody.AddForce(transform.up * power, ForceMode2D.Impulse);

        AudioManager.Current.PlayShoot();
    }

    private void HandleBurst()
    {
        m_burstCount++;
        var nozzlePosition = nozzle.position;
        var nozzleDirection = transform.up;
        if (burst < 5 && m_burstCount % (6 - burst) == 0)

            ShotGun(nozzlePosition, nozzleDirection, 1);

        else if (burst > 5)
        {
            ShotGun(nozzlePosition, nozzleDirection, 1);
            
            if (burst < 10 && m_burstCount % (11 - burst) == 0)
                ShotGun(nozzlePosition, nozzleDirection, 2);
            else if (burst > 10)
                ShotGun(nozzlePosition, nozzleDirection, 2);
        }
    }

    private void ShotGun(Vector3 _nozzlePosition, Vector3 _direction, int _pair)
    {
        var spawnedBallLeft = GetBall();
        spawnedBallLeft.SetAsBurst();
        spawnedBallLeft.transform.position = _nozzlePosition - m_ballZOffset - burstPositionOffset;
        spawnedBallLeft.gameObject.SetActive(true);
        spawnedBallLeft.rigidBody.AddForce((_direction + burstAngleOffset * _pair).normalized * power, ForceMode2D.Impulse);


        var spawnedBallRight = GetBall();
        spawnedBallRight.SetAsBurst();
        spawnedBallRight.transform.position = _nozzlePosition - m_ballZOffset + burstPositionOffset;
        spawnedBallRight.gameObject.SetActive(true);
        spawnedBallRight.rigidBody.AddForce((_direction - burstAngleOffset * _pair).normalized * power, ForceMode2D.Impulse);
    }

    //Resets cannon sprite
    private void CannonBarrelReset() => sr.sprite = sprites[0];

    private Ball GetBall()
    {
        //In case for some reason the pool
        if (m_ballPool.Count == 0)
        {
            CreateBalls(10);
        }

        //Finds an inactive ball and returns it
        foreach (var ball in m_ballPool.Where(_ball => !_ball.gameObject.activeSelf)) return ball;

        //No available balls were found, extending the pool and returning the first
        var ballFromExtendedPool = Instantiate(ballPrefab, GameManager.Current.balls);
        ballFromExtendedPool.gameObject.SetActive(false);
        m_ballPool.Add(ballFromExtendedPool);

        CreateBalls(9);

        return ballFromExtendedPool;
    }

    private void CreateBalls(int _amount)
    {
        for (var i = 0; i < _amount; i++)
        {
            var newBall = Instantiate(ballPrefab, GameManager.Current.balls);
            newBall.gameObject.SetActive(false);
            m_ballPool.Add(newBall);
        }
    }
}