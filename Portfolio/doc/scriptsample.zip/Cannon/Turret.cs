﻿using System.Collections;
using UnityEngine;

public class Turret : MonoBehaviour
{
    //Singleton
    public static Turret Current;
    public float aimRadius = 10f;

    [SerializeField]
    private TurretBall ball;

    private Vector3 m_ballZOffset = new Vector3(0, 0, -1);

    [Header("Properties")]
    private const int BASE_DAMAGE = 3;

    private const float BASE_FIRERATE = 1.0f;
    private bool m_isShooting;
    public LayerMask crateLayerMask;

    [SerializeField]
    private Transform nozzle;

    [HideInInspector]
    public Vector3 offset = new Vector3(0, 0, -90);

    public int piercing;
    private Coroutine m_shooting;
    public Sprite[] sprites;

    [Header("Assignments")]
    public SpriteRenderer sr;

    [Header("AI")]
    private GameObject m_target;

    private Quaternion m_turretAngle;
    private bool m_inMenu;

    private void Start()
    {
        m_inMenu = GameObject.Find("MenuManager") != null;
    }

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);

        //Because the turret uses PlayerPrefs for permanent upgrades, minor modifications have to be made to work cross scenes
        if (GameObject.Find("MenuManager") != null) return;
    }

    public static int GetDamage()
    {
        //Adds the permanent upgrades to the base damage
        return BASE_DAMAGE + PlayerPrefs.GetInt("turretDamage");
    }

    public static float GetFireRate()
    {
        //Adds the permanent upgrades to the fire rate
        if (PlayerPrefs.GetInt("turretFireRate") >= 15) return 0.25f; //Limits to 19 upgrades
        return BASE_FIRERATE - PlayerPrefs.GetInt("turretFireRate") / 20.0f;
    }

    private void Update()
    {
        //Ignores all AI if on the Menu
        if (m_inMenu) return;
        AimAtTarget();
        FireStatus();
    }

    //Only shoots if a target is on sight
    private Coroutine FireStatus()
    {
        //Stop firing if the upgrade screen is on:
        if (!GameManager.Current.upgradeScreen.activeSelf && m_target != null)
        {
            if (!m_isShooting) m_shooting = StartCoroutine(Shooting());
        }
        else
        {
            if (!m_isShooting) return m_shooting;
            StopCoroutine(m_shooting);
            m_isShooting = false;
        }

        return m_shooting;
    }

    private IEnumerator Shooting()
    {
        while (true)
        {
            m_isShooting = true;
            yield return new WaitForSeconds(GetFireRate());

            //Visual Feedback
            sr.sprite = sprites[1];
            Invoke(nameof(TurretBarrelReset), .1f);
            AudioManager.Current.PlayShoot();

            //Spawns the balls
            var ballInstance = Instantiate(ball, nozzle.position - m_ballZOffset, Quaternion.identity, GameManager.Current.balls);

            //Possible permanent piercing upgrade
            if (piercing == 0) ballInstance.GetComponent<Rigidbody2D>().AddForce(transform.up * .4f, ForceMode2D.Impulse);
            if (piercing > 0) ballInstance.GetComponent<Rigidbody2D>().AddForce(transform.up * 10f, ForceMode2D.Impulse);
        }
    }

    private void TurretBarrelReset()
    {
        sr.sprite = sprites[0];
    }

    //Simple aiming AI
    private void AimAtTarget()
    {
        //Loops through all crates in the radius of the turret and sets target
        var crates = Physics2D.OverlapCircleAll(transform.position, aimRadius, crateLayerMask);
        foreach (var crate in crates)
        {
            if (m_target == null) m_target = crate.gameObject;
            if (Vector3.Distance(transform.position, crate.transform.position) < Vector3.Distance(transform.position, m_target.transform.position)) m_target = crate.gameObject;
        }

        if (m_target == null) return;

        //Aims at the target
        var direction = m_target.transform.position - transform.position;
        var angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        m_turretAngle = Quaternion.AngleAxis(angle, Vector3.forward) * Quaternion.Euler(offset);
        transform.rotation = m_turretAngle;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, aimRadius);
    }
}