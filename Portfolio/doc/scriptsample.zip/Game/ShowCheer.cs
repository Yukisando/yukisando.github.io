﻿using System.Collections;
using UnityEngine;

public class ShowCheer : MonoBehaviour
{

    //Much like the popup class, it display the cheering message inbetween waves for a short time
    public GameObject cheer;

    private void OnEnable()
    {
        transform.localScale = Vector3.zero;
        StartCoroutine(GrowUpgrades());
    }

    private IEnumerator GrowUpgrades()
    {
        while (transform.localScale.x < 1f)
        {
            yield return new WaitForEndOfFrame();
            transform.localScale += new Vector3(.1f, .1f, .1f);
        }

        yield return new WaitForSeconds(.3f);
        cheer.SetActive(true);
    }

    private IEnumerator ShrinkUpgrades()
    {
        while (transform.localScale.x > 0f)
        {
            yield return new WaitForEndOfFrame();
            transform.localScale -= new Vector3(.3f, .3f, .3f);
        }

        transform.localScale = Vector3.zero;
    }

    private void OnDisable()
    {
        // StartCoroutine(ShrinkUpgrades());
        cheer.SetActive(false);
    }

}