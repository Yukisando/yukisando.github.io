﻿using UnityEngine;

public class Cp : MonoBehaviour
{

    public bool fall;
    private Rigidbody2D m_rb;
    public float speed = 2;

    private Vector3 m_target;

    private void Awake()
    {
        m_target = GameObject.FindGameObjectWithTag("ItemCatcher").transform.position;
    }

    private void Start()
    {
        Invoke(nameof(Fall), .3f);
    }

    private void FixedUpdate()
    {
        //Adds gravity to the Crate parts for a small time before making them kinematic and send them towards the container
        if (!fall) return;
        var step = speed * Time.fixedDeltaTime; // calculate distance to move
        transform.position = Vector3.MoveTowards(transform.position, m_target, step);
        if (Vector3.Distance(transform.position, m_target) < 0.001f) Destroy(gameObject);
    }

    private void Fall()
    {
        fall = true;
        m_rb = GetComponent<Rigidbody2D>();
        m_rb.velocity = Vector3.zero;
        m_rb.mass = 1;
        m_rb.gravityScale = 0;
    }

}