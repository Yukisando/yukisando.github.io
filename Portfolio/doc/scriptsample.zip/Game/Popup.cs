﻿using TMPro;
using UnityEngine;

public class Popup : MonoBehaviour
{

    private bool m_dismiss;
    public float duration = 1.3f;

    //A Simple popup gameobject to quickly display temporary information
    public TextMeshProUGUI popupText;

    private void Awake()
    {
        if (!popupText) popupText = GetComponent<TextMeshProUGUI>();
    }

    private void OnEnable()
    {
        transform.localScale = Vector3.zero;
        Invoke("Dismiss", duration);
    }

    private void Update()
    {
        if (transform.localScale.x < 1.5f && !m_dismiss) transform.localScale += new Vector3(.1f, .1f, .1f);

        if (transform.localScale.x > 1.5f && m_dismiss)
        {
            transform.localScale -= new Vector3(.2f, .2f, .2f);
        }
        else if (m_dismiss)
        {
            transform.localScale = Vector3.zero;
            m_dismiss = false;
            gameObject.SetActive(false);
        }
    }

    private void Dismiss()
    {
        m_dismiss = true;
    }

}