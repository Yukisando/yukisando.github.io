﻿using UnityEngine;

public class Assets : MonoBehaviour
{
    //Singleton:
    public static Assets Current;

    public GameObject ballTouch;
    public Sprite blazeSprite;
    public Sprite bounceSprite;

    [Header("Upgrades")] public Sprite burstSprite;

    //Collection of assets for easy access
    [Header("Particles")] public GameObject crateBreak;

    [Header("Items")] public GameObject crateSplash;
    public Sprite electricSprite;
    public GameObject electricTouch;
    public Sprite firerateSprite;
    public GameObject fireTouch;
    public Sprite freezeSprite;
    public GameObject freezeTouch;
    public Sprite limitSprite;
    public Sprite powerSprite;
    public Sprite sizeSprite;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
    }
}