﻿using System.Collections;
using TMPro;
using UnityEngine;

//Cheer popup for good and bad rounds
public class Cheers : MonoBehaviour
{

    private TextMeshProUGUI m_cheerText;

    private void Awake()
    {
        m_cheerText = GetComponent<TextMeshProUGUI>();
    }

    private void OnEnable()
    {
        m_cheerText.text = " ";
        transform.localScale = Vector3.zero;
        m_cheerText.text = SelectedCheer();
        StartCoroutine(GrowText());
    }

    //List of possible texts
    private string SelectedCheer()
    {
        var quotesBad = new[] {"Pathetic", "Shameful", "Sad really", "Is this all you got?", "Horrid", "Is your screen on?", "My grandma does better"};
        var quotesOk = new[] {"Sloppy", "Meh", "Alright", "Decent", "I've seen worse", "Okay...ish"};
        var quotesGood = new[] {"Amazing!", "Superb!", "WoW!", "Good job!", "Sick!", "Well Done!", "Bravo!"};
        var quotesPerfect = new[] {"Godlike!", "Perfect!", "Inhuman!", "Chuck Norris", "Wombo Combo", "#Pygmak"};

        //Random selection for each category
        var select = 0;
        if (Cannon.Current.health < 10) select = 0;
        if (Cannon.Current.health >= 10 && Cannon.Current.health < 50) select = 1;
        if (Cannon.Current.health >= 50 && Cannon.Current.health < 95) select = 2;
        if (Cannon.Current.health >= 95) select = 3;

        switch (select)
        {
            case 0:
                return quotesBad[Random.Range(0, quotesBad.Length)];
            case 1:
                return quotesOk[Random.Range(0, quotesOk.Length)];
            default:
            case 2:
                return quotesGood[Random.Range(0, quotesGood.Length)];
            case 3:
                return quotesPerfect[Random.Range(0, quotesPerfect.Length)];
        }
    }

    //The popup display
    private IEnumerator GrowText()
    {
        while (transform.localScale.x < 1.5f)
        {
            yield return new WaitForEndOfFrame();
            transform.localScale += new Vector3(.1f, .1f, .1f);
        }
    }

}