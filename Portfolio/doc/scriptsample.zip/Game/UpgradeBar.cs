﻿using UnityEngine;

public class UpgradeBar : MonoBehaviour
{

    public static UpgradeBar I;
    public GameObject lvlNode;
    public Animator slideAnim;

    private void Awake()
    {
        if (I == null) I = this;
        else if (I != this) Destroy(I);
    }

    //Adds the upgrade nodes to the bar
    public void ExpBarAdd()
    {
        Instantiate(lvlNode, transform.position, transform.rotation, transform);
    }

    //Show and hide the upgradebar
    public void Show(bool _state)
    {
        slideAnim.SetBool("Pause", _state);
    }

}