﻿using UnityEngine;
using UnityEngine.UI;

public class Mute : MonoBehaviour
{

    private Image m_img;
    public Sprite mutedSprite;
    public Sprite unmutedSprite;

    private void Awake()
    {
        m_img = GetComponent<Image>();
    }

    public void MuteToggle()
    {
        AudioListener.pause = !AudioListener.pause;
        m_img.sprite = AudioListener.pause ? mutedSprite : unmutedSprite;
    }

}