﻿using UnityEngine;

public class RemoveMass : MonoBehaviour
{

    //This puts back a normal weight on the crates after they hit the trigger
    private void OnTriggerEnter2D(Collider2D _other)
    {
        if (_other.gameObject.CompareTag("Crate")) _other.GetComponent<Rigidbody2D>().mass = 1.3f;
    }

}