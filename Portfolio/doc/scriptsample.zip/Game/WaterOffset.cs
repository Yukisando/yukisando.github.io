﻿using UnityEngine;

public class WaterOffset : MonoBehaviour
{
    private Material m_mat;

    //Simply makes the water the bottom move from side to side
    private SpriteRenderer m_sr;

    public float xoffset = 2;
    public float xoffsetSpeed = 1.0f;
    private static readonly int MainTex = Shader.PropertyToID("_MainTex");

    private void Awake()
    {
        m_sr = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        m_sr.material.SetTextureOffset(MainTex, new Vector2(Mathf.Sin(Time.time * xoffset) * xoffsetSpeed, 0));
    }
}