﻿using TMPro;
using UnityEngine;

public class MenuManager : MonoBehaviour
{
    [Header("Upgrades:")] 
    public int cannonSkin1Cost = 30000;
    public TextMeshProUGUI cannonSkin1CostText;
    public GameObject cannonSkin1Lock;
    public int cannonSkin2Cost = 60000;
    public TextMeshProUGUI cannonSkin2CostText;
    public GameObject cannonSkin2Lock;
    public TextMeshProUGUI cpsText;
    public TextMeshProUGUI highscoreText;

    [Header("Panels:")] 
    public GameObject popupInfo;
    public GameObject turretBuy;

    public int turretCost = 8000;
    public TextMeshProUGUI turretDamage;
    public int turretDamageCost = 10000;
    public TextMeshProUGUI turretDamageCostText;

    [Header("Info:")] public TextMeshProUGUI turretFireRate;
    public int turretFireRateCost = 10000;
    public TextMeshProUGUI turretFireRateCostText;
    public GameObject turretLock;

    private void Start()
    {
        //Starts by fading out
        Fader.Current.FadeOut();
        Time.timeScale = 1;
        UpdateUi();
    }

    private void Update()
    {
        //I can afford to have a few things in the update here as the menu is very light
        highscoreText.text = "Best: " + PlayerPrefs.GetInt("highscore");

        if (PlayerPrefs.GetInt("turret") >= 1)
        {
            turretBuy.SetActive(false);
            turretLock.SetActive(false);
        }
        else
        {
            turretBuy.SetActive(true);
            turretLock.SetActive(true);
        }

        cannonSkin1Lock.SetActive(PlayerPrefs.GetInt("cannonSkin1") < 1);
        cannonSkin2Lock.SetActive(PlayerPrefs.GetInt("cannonSkin2") < 1);
    }

    private void UpdateUi()
    {
        //Sets all the string to their saved settings
        cpsText.text = PlayerPrefs.GetInt("cps").ToString("n0");
        turretDamage.text = Turret.GetDamage().ToString();
        turretFireRate.text = Turret.GetFireRate().ToString("F3");
        turretFireRateCostText.text = turretFireRateCost.ToString("n0") + " CP";
        turretDamageCostText.text = turretDamageCost.ToString("n0") + " CP";
        cannonSkin1CostText.text = cannonSkin1Cost.ToString("n0") + " HS";
        cannonSkin2CostText.text = cannonSkin2Cost.ToString("n0") + " HS";
    }

    //Goes to the Endless scene
    public void StartEndless()
    {
        Fader.Current.FadeIn("Endless");
    }

    //Goes to the StartCity_Night beta scene
    public void StartCityNight()
    {
        Fader.Current.FadeIn("City_Night");
    }

    //Goes to the upcoming StartCity scene
    public void StartStory()
    {
        popupInfo.SetActive(true);
        popupInfo.GetComponent<Popup>().popupText.text = "Coming soon!";
    }

    //Mainly for debug purposes, it will have it's own section in the settings
    public void ResetScore()
    {
        PlayerPrefs.SetInt("highscore", 0);
        highscoreText.text = "Best: 0";
        PlayerPrefs.SetInt("cps", 0);
        cpsText.text = "0";
        PlayerPrefs.SetInt("turret", 0);
        PlayerPrefs.SetInt("turretDamage", 0);
        PlayerPrefs.SetInt("turretFireRate", 0);
        UpdateUi();
    }

    //Upgrade Screen
    public void UnlockCannonSkin1()
    {
        if (PlayerPrefs.GetInt("cannonSkin1") == 1)
        {
            //Set skin
        }

        if (PlayerPrefs.GetInt("highscore") > cannonSkin1Cost)
        {
            PlayerPrefs.SetInt("cannonSkin1", 1);
        }
        else
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get a highscore of " + cannonSkin1Cost;
        }

        UpdateUi();
    }

    //Unlock the different permanent upgrades and skins
    public void UnlockCannonSkin2()
    {
        if (PlayerPrefs.GetInt("cannonSkin2") == 1)
        {
            //Set skin
        }

        if (PlayerPrefs.GetInt("highscore") > cannonSkin2Cost)
        {
            PlayerPrefs.SetInt("cannonSkin2", 1);
        }
        else
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get a highscore of " + cannonSkin2Cost;
        }

        UpdateUi();
    }

    public void UnlockTurret()
    {
        if (PlayerPrefs.GetInt("cps") > turretCost)
        {
            PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") - turretCost);
            PlayerPrefs.SetInt("turret", 1);
        }
        else
        {
            var amount = turretCost - PlayerPrefs.GetInt("cps");
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get " + amount + " more Crate Parts!";
        }

        UpdateUi();
    }

    public void UpgradeTurretDamage()
    {
        if (PlayerPrefs.GetInt("turret") != 1)
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Requires 'Turret'";
            return;
        }

        if (PlayerPrefs.GetInt("cps") >= turretDamageCost)
        {
            PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") - turretDamageCost);
            PlayerPrefs.SetInt("turretDamage", PlayerPrefs.GetInt("turretDamage") + 1);
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Turret damage +" + PlayerPrefs.GetInt("turretDamage");
        }
        else
        {
            var amountDue = turretDamageCost - PlayerPrefs.GetInt("cps");
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get " + amountDue + " more Crate Parts!";
        }

        UpdateUi();
    }

    public void UpgradeTurretFireRate()
    {
        if (PlayerPrefs.GetInt("turret") != 1)
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Requires 'Turret'";
            return;
        }

        if (PlayerPrefs.GetInt("cps") >= turretFireRateCost)
        {
            PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") - turretFireRateCost);
            PlayerPrefs.SetInt("turretFireRate", PlayerPrefs.GetInt("turretFireRate") + 1);
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Turret firerate +" + PlayerPrefs.GetInt("turretFireRate");
        }
        else
        {
            var amountDue = turretFireRateCost - PlayerPrefs.GetInt("cps");
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get " + amountDue + " more Crate Parts!";
        }

        UpdateUi();
    }
}