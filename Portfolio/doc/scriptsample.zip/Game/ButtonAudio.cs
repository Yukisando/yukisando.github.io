using UnityEngine;
using UnityEngine.EventSystems;

public class ButtonAudio : MonoBehaviour, IPointerEnterHandler, IPointerClickHandler
{

    public void OnPointerClick(PointerEventData _pointerEventData)
    {
        AudioManager.Current.PlaySelectClip();
    }

    //Simple UI button audio manager for hover and click events

    public void OnPointerEnter(PointerEventData _pointerEventData)
    {
        AudioManager.Current.PlayHoverClip();
    }

}