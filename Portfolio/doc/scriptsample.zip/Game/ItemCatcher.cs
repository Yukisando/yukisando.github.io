﻿using System.Collections;
using System.Linq;
using UnityEngine;

public class ItemCatcher : MonoBehaviour
{

    private int m_cps;

    private AudioSource m_source;
    private Vector3 m_startScale;
    private Transform m_;

    private void Awake()
    {
        m_source = GetComponent<AudioSource>();
        m_startScale = transform.localScale;
        m_cps = PlayerPrefs.GetInt("cps");
        m_ = GetComponent<Transform>();
    }

    public void Add()
    {
        m_cps++;
        PlayerPrefs.SetInt("cps", m_cps);
        StartCoroutine(VisualFeedback());
    }

    private IEnumerator VisualFeedback()
    {
        m_source.volume = .3f;
        m_source.pitch = Random.Range(.7f, 1.3f);
        if (!AudioListener.pause) m_source.PlayOneShot(m_source.clip);
        m_.localScale += Vector3.one / 10;
        yield return new WaitForSeconds(.04f);
        m_.localScale = m_startScale;
    }
}