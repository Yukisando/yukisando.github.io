using UnityEngine;

public class AudioManager : MonoBehaviour
{
    //Singleton
    public static AudioManager Current;

    [Header("Clips")] public AudioClip shootClip;

    public AudioClip wallHitClip;
    public AudioClip crateBlazeHitClip;
    public AudioClip[] crateBreakClips;
    public AudioClip crateElectricHitClip;
    public AudioClip crateFailClip;
    public AudioClip crateFrozenHitClip;
    public AudioClip[] crateHitClips;

    //UI
    public AudioClip hoverItemClip;
    public AudioClip itemPickupClip;
    public AudioClip selectItemClip;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
    }

    //Shoot implement pooling system!
    public void PlayShoot()
    {
        // Create Gameobject and attach audiosource
        var shootSound = new GameObject("ShootSound", typeof(AudioSource)).GetComponent<AudioSource>();
        shootSound.pitch = Random.Range(.3f, 1.3f);
        shootSound.volume = .7f;
        shootSound.PlayOneShot(shootClip);
        shootSound.transform.parent = GameManager.Current.clips;
        Destroy(shootSound.transform.gameObject, 1f);
    }

    public void PlayCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateHitSound = new GameObject("CrateHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateHitSound.volume = .5f;
        crateHitSound.pitch += Random.Range(-.3f, .3f);
        crateHitSound.PlayOneShot(crateHitClips[Random.Range(0, crateHitClips.Length)]);
        crateHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateHitSound.transform.gameObject, 1f);
    }

    public void PlayFrozenCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateFrozenHitSound = new GameObject("CrateFrozenHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateFrozenHitSound.volume = .5f;
        crateFrozenHitSound.pitch += Random.Range(-.3f, .3f);
        crateFrozenHitSound.PlayOneShot(crateFrozenHitClip);
        crateFrozenHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateFrozenHitSound.transform.gameObject, 1f);
    }

    public void PlayBlazeCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateBlazeHitSound = new GameObject("CrateBlazeHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateBlazeHitSound.volume = .5f;
        crateBlazeHitSound.pitch += Random.Range(-.3f, .3f);
        crateBlazeHitSound.PlayOneShot(crateBlazeHitClip);
        crateBlazeHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateBlazeHitSound.transform.gameObject, 1f);
    }

    public void PlayElectricCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateElectricHitSound = new GameObject("CrateElectricHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateElectricHitSound.volume = .5f;
        crateElectricHitSound.pitch += Random.Range(0f, .3f);
        crateElectricHitSound.PlayOneShot(crateElectricHitClip);
        crateElectricHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateElectricHitSound.transform.gameObject, 1f);
    }

    public void PlayCrateBreak()
    {
        // Create Gameobject and attach audiosource
        var crateBreakSound = new GameObject("CrateBreak", typeof(AudioSource)).GetComponent<AudioSource>();
        crateBreakSound.pitch += Random.Range(-.3f, 0f);
        crateBreakSound.PlayOneShot(crateBreakClips[Random.Range(0, crateBreakClips.Length)]);
        crateBreakSound.transform.parent = GameManager.Current.clips;
        Destroy(crateBreakSound.transform.gameObject, 1f);
    }

    public void PlayCrateFail()
    {
        // Create Gameobject and attach audiosource
        var crateFailSound = new GameObject("CrateFail", typeof(AudioSource)).GetComponent<AudioSource>();
        crateFailSound.pitch += Random.Range(-.3f, .3f);
        crateFailSound.PlayOneShot(crateFailClip);
        crateFailSound.transform.parent = GameManager.Current.clips;
        Destroy(crateFailSound.transform.gameObject, 1f);
    }

    public void PlayHoverClip()
    {
        var hoverSound = new GameObject("Hover", typeof(AudioSource)).GetComponent<AudioSource>();
        DontDestroyOnLoad(hoverSound.gameObject);
        hoverSound.pitch += Random.Range(-.3f, .3f);
        hoverSound.PlayOneShot(hoverItemClip);
        Destroy(hoverSound.transform.gameObject, 1f);
    }

    public void PlaySelectClip()
    {
        var selectSound = new GameObject("Select", typeof(AudioSource)).GetComponent<AudioSource>();
        DontDestroyOnLoad(selectSound.gameObject);
        selectSound.pitch += Random.Range(-.3f, .3f);
        selectSound.PlayOneShot(selectItemClip);
        Destroy(selectSound.transform.gameObject, 1f);
    }

    public void PlayWallHit()
    {
        var wallHitSound = new GameObject("WallHit", typeof(AudioSource)).GetComponent<AudioSource>();
        DontDestroyOnLoad(wallHitSound.gameObject);
        wallHitSound.pitch += Random.Range(-.3f, .3f);
        wallHitSound.volume = .05f;
        wallHitSound.PlayOneShot(wallHitClip);
        Destroy(wallHitSound.transform.gameObject, 1f);
    }
}