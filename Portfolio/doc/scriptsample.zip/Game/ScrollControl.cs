using UnityEngine;
using UnityEngine.UI;

internal class ScrollControl : MonoBehaviour
{

    private RectTransform m_scrollTransform;
    private Vector3 m_startPosition;

    //Handles the navigation menu, its scrolling behaviour
    //Must implement "snap" functionality
    private void Start()
    {
        m_scrollTransform = GetComponent<RectTransform>();
        m_startPosition = m_scrollTransform.position;
    }

    public void GoToUpgrades()
    {
        m_scrollTransform.position = new Vector3(6.1f, 0, 3.6f);
    }

    public void GoToEndless()
    {
        m_scrollTransform.position = m_startPosition;
    }

    public void GoToStory()
    {
        m_scrollTransform.position = new Vector3(-5.1f, 0, 3.6f);
    }

}