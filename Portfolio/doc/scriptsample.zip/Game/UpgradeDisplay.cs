using UnityEngine;
using UnityEngine.UI;

public class UpgradeDisplay : MonoBehaviour
{

    public GameObject upgradePf;

    //Adds the selected upgrade to the upgrade display in the pause menu for quick recap
    public void AddToList(Sprite _sprite)
    {
        var obj = Instantiate(upgradePf, GetComponent<GridLayoutGroup>().transform, false);
        obj.GetComponent<Image>().sprite = _sprite;
    }

}