﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Fader : MonoBehaviour
{

    public static Fader Current;
    public Animator animator;
    public Image fadeScreen;
    private static readonly int Fade = Animator.StringToHash("Fade");

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
    }

    public void FadeIn(string _sceneName)
    {
        StartCoroutine(FadeInCoroutine(_sceneName));
    }

    public void FadeOut()
    {
        StartCoroutine(FadeOutCoroutine());
    }

    //Simply handles a fading animation in between scenes
    private IEnumerator FadeInCoroutine(string _sceneName)
    {
        animator.SetBool(Fade, true);
        yield return new WaitUntil(() => Math.Abs(fadeScreen.color.a - 1) < 0.01f);
        SceneManager.LoadScene(_sceneName);
    }

    private IEnumerator FadeOutCoroutine()
    {
        animator.SetBool("Fade", false);
        yield return new WaitUntil(() => Math.Abs(fadeScreen.color.a) < 0.01f);
    }

}