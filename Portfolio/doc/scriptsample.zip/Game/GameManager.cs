using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    //Singleton:
    public static GameManager Current;

    [Header("Rubbish Pickup")]
    public Transform balls;
    public Transform clips;
    public TextMeshProUGUI cratePartPauseText;
    public TextMeshProUGUI cratePartText;
    public Transform crates;
    public GameObject endGameScreen;
    public bool endless;
    public GameObject gameOverScreen;
    public TextMeshProUGUI healthText;
    [HideInInspector] public int highscore;
    public TextMeshProUGUI highscoreText;
    public Transform items;
    public bool nightScene;
    public Transform particles;
    public GameObject pauseButton;
    public GameObject pauseScreen;
    public Popup popup;

    [HideInInspector] public int score;
    public TextMeshProUGUI scoreText;
    public GameObject turret;

    [Header("Turret")] 
    public bool turretForcedEnabled;
    private Button m_upgradeButton1;
    private Button m_upgradeButton2;
    private Button m_upgradeButton3;
    public int upgradeCount;

    [Header("Upgrades")]
    public int upgradeCountLimit = 20;
    public UpgradeDisplay upgradeDisplay;

    //Upgrades:
    private int m_upgradeHealthCounter;
    public Popup upgradeInfoPopup;

    [Header("UI")]
    public GameObject upgradeScreen;
    public GameObject[] upgradeSlots = new GameObject[3];
    private Sprite[] m_upgradeSprites;

    public TextMeshProUGUI waveNumberText;

    [Header("Settings")]
    public int waveSize = 30;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);

        //Android setup
        Application.targetFrameRate = 300;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        //Advertisement.Initialize();

        //Remove collisions between balls (Potentialy add ghost upgrade for this benefit?)
        Physics2D.IgnoreLayerCollision(LayerMask.NameToLayer("Ball"), LayerMask.NameToLayer("SideBall"));
        Physics2D.IgnoreLayerCollision(LayerMask.NameToLayer("Ball"), LayerMask.NameToLayer("Ball"));

        //Makes sure the upgrades are ready for the first upgrade
        Time.timeScale = 1;
        m_upgradeSprites = Resources.LoadAll<Sprite>("Upgrades Atlas");

        //Rubbish collection to avoid overflow of gameobjects in the hierrachy
        balls = GameObject.Find("Balls").transform;
        crates = GameObject.Find("Crates").transform;
        clips = GameObject.Find("Clips").transform;

        //Setup scores
        score = 0;
        highscore = PlayerPrefs.GetInt("highscore");
    }

    private void Start()
    {
        //Init upgrade buttons
        m_upgradeButton1 = upgradeSlots[0].GetComponent<Button>();
        m_upgradeButton2 = upgradeSlots[1].GetComponent<Button>();
        m_upgradeButton3 = upgradeSlots[2].GetComponent<Button>();

        //Activate Turret if unlocked
        turret.SetActive(PlayerPrefs.GetInt("turret") == 1);

        //For Debug
        if (turretForcedEnabled) turret.SetActive(true);
    }

    private void LateUpdate()
    {
        UpdateUi();
    }

    //UI text updates (Needs optimization, no need every frame)
    private void UpdateUi()
    {
        scoreText.text = score.ToString();
        highscoreText.text = "Best: " + highscore;
        cratePartText.text = PlayerPrefs.GetInt("cps").ToString();
        waveNumberText.text = CrateSpawner.Current.waveNumber.ToString();
        if (!upgradeScreen.activeSelf) healthText.text = Cannon.Current.health.ToString();
    }

    //Deals the health of the crate as damage to the player when a crate goes through
    public void DealDamageToPlayer(int _amount)
    {
        Cannon.Current.health -= _amount;

        //Gameover on death
        if (Cannon.Current.health <= 0 && !upgradeScreen.activeSelf) GameOver();
    }

    //Quick extra save, display pause screen and stop time
    public void Pause()
    {
        pauseButton.SetActive(false);
        cratePartPauseText.text = PlayerPrefs.GetInt("cps").ToString();
        Time.timeScale = 0;
        pauseScreen.SetActive(true);
    }

    //Gameover screen
    public void EndGame()
    {
        if (endGameScreen.activeSelf) return;
        if (score > highscore)
        {
            PlayerPrefs.SetInt("highscore", score);
            highscore = score;
        }

        endGameScreen.SetActive(true);
    }

    //Resume from pause
    public void Resume()
    {
        pauseScreen.SetActive(false);
        Time.timeScale = 1;
        pauseButton.SetActive(true);
    }

    public void GameOver()
    {
        if (gameOverScreen.activeSelf) return;
        Cannon.Current.dead = true;
        if (score > highscore)
        {
            if (score > PlayerPrefs.GetInt("highscore")) PlayerPrefs.SetInt("highscore", score);
            highscore = score;
        }

        gameOverScreen.SetActive(true);
    }

    //Fades to restart
    public void Restart()
    {
        Fader.Current.FadeIn(SceneManager.GetActiveScene().name);
    }

    public void Menu()
    {
        if (score > PlayerPrefs.GetInt("highscore")) PlayerPrefs.SetInt("highscore", score);
        Time.timeScale = 1;
        Fader.Current.FadeIn("Menu");
    }

    public void ShowUpgrades()
    {
        if (Cannon.Current.dead) return; //Do not show upgrade if dead
        if (upgradeCount >= upgradeCountLimit)
        {
            //Do not show upgrade if upgrade limit is reached
            upgradeInfoPopup.gameObject.SetActive(true);
            upgradeInfoPopup.popupText.text = "NEXT WAVE!";
            CrateSpawner.Current.SpawnNextWave();
            upgradeScreen.SetActive(false);

            //Note that health is no longer reset either. SURVIVE!
        }
        else
        {
            //Displays the upgrade screen
            m_upgradeHealthCounter = 0;
            score += Cannon.Current.health;
            StartCoroutine(GiveHealthCp());
            if (score > highscore)
            {
                PlayerPrefs.SetInt("highscore", score);
                highscore = score;
            }

            SetRandomUpgrades();
            upgradeScreen.SetActive(true);
            UpgradeBar.I.Show(true);
        }
    }

    private void SetRandomUpgrades()
    {
        //Initialize upgrade slots and prevents duplicates
        var randomUpgrade1 = Random.Range(0, 9);
        var randomUpgrade2 = Random.Range(0, 9);
        while (randomUpgrade2 == randomUpgrade1) randomUpgrade2 = Random.Range(0, 9);
        var randomUpgrade3 = Random.Range(0, 9);
        while (randomUpgrade3 == randomUpgrade1 || randomUpgrade3 == randomUpgrade2) randomUpgrade3 = Random.Range(0, 9);

        //Reset all listeners
        for (var i = 0; i < 3; i++)
        {
            upgradeSlots[i].GetComponent<Image>().sprite = null;
            upgradeSlots[i].GetComponent<Button>().onClick.RemoveAllListeners();
        }

        //Assigns the corresponding sprite
        upgradeSlots[0].GetComponent<Image>().sprite = m_upgradeSprites[randomUpgrade1];
        upgradeSlots[1].GetComponent<Image>().sprite = m_upgradeSprites[randomUpgrade2];
        upgradeSlots[2].GetComponent<Image>().sprite = m_upgradeSprites[randomUpgrade3];

        //Assigns the corresponding upgrade to each button
        AssignListeners(randomUpgrade1, randomUpgrade2, randomUpgrade3);
    }

    private void AssignListeners(int _randomUpgrade1, int _randomUpgrade2, int _randomUpgrade3)
    {
        switch (_randomUpgrade1)
        {
            default:
                m_upgradeButton1.onClick.AddListener(Burst);
                break;
            case 1:
                m_upgradeButton1.onClick.AddListener(IncreasePower);
                break;
            case 2:
                m_upgradeButton1.onClick.AddListener(IncreaseFireRate);
                break;
            case 3:
                m_upgradeButton1.onClick.AddListener(IncreaseSize);
                break;
            case 4:
                m_upgradeButton1.onClick.AddListener(AddFreeze);
                break;
            case 5:
                m_upgradeButton1.onClick.AddListener(IncreaseLimit);
                break;
            case 6:
                m_upgradeButton1.onClick.AddListener(IncreaseBounceLimit);
                break;
            case 7:
                m_upgradeButton1.onClick.AddListener(AddElectrify);
                break;
            case 8:
                m_upgradeButton1.onClick.AddListener(AddBlaze);
                break;
        }

        switch (_randomUpgrade2)
        {
            default:
                m_upgradeButton2.onClick.AddListener(Burst);
                break;
            case 1:
                m_upgradeButton2.onClick.AddListener(IncreasePower);
                break;
            case 2:
                m_upgradeButton2.onClick.AddListener(IncreaseFireRate);
                break;
            case 3:
                m_upgradeButton2.onClick.AddListener(IncreaseSize);
                break;
            case 4:
                m_upgradeButton2.onClick.AddListener(AddFreeze);
                break;
            case 5:
                m_upgradeButton2.onClick.AddListener(IncreaseLimit);
                break;
            case 6:
                m_upgradeButton2.onClick.AddListener(IncreaseBounceLimit);
                break;
            case 7:
                m_upgradeButton2.onClick.AddListener(AddElectrify);
                break;
            case 8:
                m_upgradeButton2.onClick.AddListener(AddBlaze);
                break;
        }

        switch (_randomUpgrade3)
        {
            default:
                m_upgradeButton3.onClick.AddListener(Burst);
                break;
            case 1:
                m_upgradeButton3.onClick.AddListener(IncreasePower);
                break;
            case 2:
                m_upgradeButton3.onClick.AddListener(IncreaseFireRate);
                break;
            case 3:
                m_upgradeButton3.onClick.AddListener(IncreaseSize);
                break;
            case 4:
                m_upgradeButton3.onClick.AddListener(AddFreeze);
                break;
            case 5:
                m_upgradeButton3.onClick.AddListener(IncreaseLimit);
                break;
            case 6:
                m_upgradeButton3.onClick.AddListener(IncreaseBounceLimit);
                break;
            case 7:
                m_upgradeButton3.onClick.AddListener(AddElectrify);
                break;
            case 8:
                m_upgradeButton3.onClick.AddListener(AddBlaze);
                break;
        }
    }

    //Gives the remains health as Crate Parts
    private IEnumerator GiveHealthCp()
    {
        while (m_upgradeHealthCounter <= Cannon.Current.health)
        {
            healthText.text = "+" + m_upgradeHealthCounter;
            m_upgradeHealthCounter++;
            CratePart cp = CratePartPool.Current.Get(true);
            cp.transform.position = transform.position + (Vector3) Random.insideUnitCircle * .4f;
            cp.transform.rotation = Random.rotation;
            cp.gameObject.SetActive(true);
            yield return null;
        }
    }

    //Upgrades:
    //--------------------

    //Shotgun effect
    private void Burst()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.burst == 0)
        {
            upgradeInfoPopup.popupText.text = "Burst";
        }
        else if (Cannon.Current.burst < Cannon.Current.burstCap)
        {
            upgradeInfoPopup.popupText.text = "Burst firerate+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Burst MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.burstSprite);
        Cannon.Current.burst++;
        ContinueGame();
    }

    //Increase speed and damage of the ball
    private void IncreasePower()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.power < Cannon.Current.powerCap)
        {
            upgradeInfoPopup.popupText.text = "Cannon Power+";
            Cannon.Current.power += .1f;
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Power MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.powerSprite);
        Cannon.Current.damage++;
        ContinueGame();
    }

    //Increase fire rate of the cannon
    private void IncreaseFireRate()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.fireRate < Cannon.Current.fireRateCap)
        {
            upgradeInfoPopup.popupText.text = "Firerate+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Firerate MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.firerateSprite);
        Cannon.Current.fireRate += .6f;
        ContinueGame();
    }

    //Increase size and damage of the ball (More mass means more stopping power too!)
    private void IncreaseSize()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.ballSizeIncrease < Cannon.Current.sizeCap)
        {
            upgradeInfoPopup.popupText.text = "Ball size+";
            Cannon.Current.ballSizeIncrease += .12f;
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Size MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.sizeSprite);
        Cannon.Current.damage++;
        ContinueGame();
    }

    //Adds a chill effect
    private void AddFreeze()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.freeze == 0)
        {
            upgradeInfoPopup.popupText.text = "Freeze";
        }
        else if (Cannon.Current.freeze < Cannon.Current.freezeCap)
        {
            upgradeInfoPopup.popupText.text = "Freeze duration+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Freeze MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.freezeSprite);
        Cannon.Current.freeze++;
        ContinueGame();
    }

    //Increase the maximum of balls on screen possible (A little too abstract. Needs replacement)
    private void IncreaseLimit()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.countLimit < Cannon.Current.countLimitCap)
        {
            upgradeInfoPopup.popupText.text = "Ball count limit+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Ball count limit MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.limitSprite);
        Cannon.Current.countLimit += 5;
        ContinueGame();
    }

    //Increases the number of bounces before destroying the ball
    private void IncreaseBounceLimit()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.bounceLimit < Cannon.Current.bounceLimitCap)
        {
            upgradeInfoPopup.popupText.text = "Bounce+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Bounce limit MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.bounceSprite);
        Cannon.Current.bounceLimit++;
        ContinueGame();
    }

    //Deals AOE damage to all crates in the radius (Each upgrade increases the radius and damage of the effect)
    private void AddElectrify()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.electrify == 0)
        {
            upgradeInfoPopup.popupText.text = "Electrify";
        }
        else if (Cannon.Current.electrify < Cannon.Current.electrifyCap)
        {
            upgradeInfoPopup.popupText.text = "Electrify radius+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Electrify MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.electricSprite);
        Cannon.Current.electrify++;
        ContinueGame();
    }

    //Sets crates on fire (DOT damage)
    private void AddBlaze()
    {
        if (upgradeCount >= upgradeCountLimit) return;
        Cannon.Current.health = 100;
        upgradeInfoPopup.gameObject.SetActive(true);
        if (Cannon.Current.blaze == 0)
        {
            upgradeInfoPopup.popupText.text = "Blaze";
        }
        else if (Cannon.Current.blaze <= Cannon.Current.blazeCap)
        {
            upgradeInfoPopup.popupText.text = "Blaze duration+";
        }
        else
        {
            upgradeInfoPopup.popupText.text = "Blaze MAX";
            return;
        }

        upgradeDisplay.AddToList(Assets.Current.blazeSprite);
        Cannon.Current.blaze++;
        ContinueGame();
    }

    //Resets stats and spawns next wave
    private void ContinueGame()
    {
        CrateSpawner.Current.SpawnNextWave();
        upgradeScreen.SetActive(false);
        upgradeCount++;
        UpgradeBar.I.ExpBarAdd();
        UpgradeBar.I.Show(false);
    }
}