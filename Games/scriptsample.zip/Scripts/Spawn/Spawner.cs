﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Spawner : MonoBehaviour {
    public bool spawn = true;
    public GameObject jumpBlock;
    public GameObject crouchBlock;
    public GameObject attackBlock;
    public GameObject lifeBlock;
    public int blocksToLife = 55;

    float crouchBlockHeight = 1.5f;
    float lifeBlockHeight = 2.1f;
    Vector3 crouchBlockPosition;
    Vector3 lifeBlockPosition;
    int counter;

    void Start() {
        //Sets the height of the crouchBlock
        crouchBlockPosition = new Vector3(transform.position.x, transform.position.y + crouchBlockHeight, transform.position.z);
        lifeBlockPosition = new Vector3(transform.position.x, transform.position.y + lifeBlockHeight, transform.position.z);
        counter = 0;

        //Starts the spawn
        StartCoroutine(Spawn());
    }

    IEnumerator Spawn() {
        while (spawn) {
            //Pick the next block:
            int picker = Random.Range(1, 4);

            //Checks if a life should be given
            if (counter >= blocksToLife) {
                Instantiate(lifeBlock, lifeBlockPosition, Quaternion.identity, transform);
                GameAssets.i.PlayLifeBlock();
                counter = 0;

                //If not spawn random block:
            } else switch (picker) {
                case 1:
                    Instantiate(jumpBlock, transform.position, Quaternion.identity, transform);
                    GameAssets.i.PlayJumpBlock();
                    break;
                case 2:
                    Instantiate(crouchBlock, crouchBlockPosition, Quaternion.identity, transform);
                    GameAssets.i.PlayCrouchBlock();
                    break;
                case 3:
                    Instantiate(attackBlock, transform.position, Quaternion.identity, transform);
                    GameAssets.i.PlayAttackBlock();
                    break;
                default:
                    Instantiate(attackBlock, transform.position, Quaternion.identity, transform);
                    GameAssets.i.PlayAttackBlock();
                    break;
            }
            //Increase game difficulty
            if (SceneManager.GetActiveScene().name != "Menu") {
                if (GameHandler.blockSpawnRate >= .6) GameHandler.blockSpawnRate -= .03f;
                if (GameHandler.gameSpeed <= 15) GameHandler.gameSpeed += .3f;
                counter++;
            }

            yield return new WaitForSeconds(GameHandler.blockSpawnRate);
        }
        yield return null;
    }

    //Spawning position helper
    private void OnDrawGizmos() {
        Gizmos.color = Color.magenta;
        Gizmos.DrawRay(transform.position, Vector2.left * 25);
    }
}