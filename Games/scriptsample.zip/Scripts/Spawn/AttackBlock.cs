﻿using UnityEngine;

public class AttackBlock : MonoBehaviour {
    public GameObject particleEffectPrefab;

    void Update() {
        transform.position -= new Vector3(GameHandler.gameSpeed, 0, 0) * Time.deltaTime;
        transform.rotation = Quaternion.Euler(15f * Mathf.Sin(Time.time * 12.0f), 0f, 0f);
    }

    public void Remove() {
        gameObject.SetActive(false);
        Instantiate(particleEffectPrefab, transform.position, Quaternion.identity);
        Destroy(gameObject, 1f);
    }

    private void OnBecameInvisible() => Destroy(gameObject, 1f);

    private void OnTriggerEnter2D() => Destroy(gameObject);
}