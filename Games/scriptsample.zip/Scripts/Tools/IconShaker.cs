﻿using UnityEngine;

public class IconShaker : MonoBehaviour {
    public float speed = 10f;
    public float maxRotation = 45f;

    private void Update() => transform.rotation = Quaternion.Euler(0f, 0f, maxRotation * Mathf.Sin(Time.time * speed));

}