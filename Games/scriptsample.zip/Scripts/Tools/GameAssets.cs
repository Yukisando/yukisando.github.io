﻿using UnityEngine;

public class GameAssets : MonoBehaviour {
    public static GameAssets i;

    AudioSource source;

    // Makes sure only one instance exists and prevents deletion between scenes
    private void Awake() {
        DontDestroyOnLoad(this);
        if (i == null) {
            i = this;
        } else {
            Destroy(gameObject);
        }

        source = gameObject.AddComponent<AudioSource>();
        source.playOnAwake = false;
    }

    //Player clips:
    [Header("Player clips:")]
    public AudioClip jumpClip;
    public AudioClip crouchClip;
    public AudioClip attackClip;
    public AudioClip lifeClip;
    public AudioClip hitClip;

    //World clips:
    [Header("World clips:")]
    public AudioClip jumpBlockClip;
    public AudioClip crouchBlockClip;
    public AudioClip attackBlockClip;
    public AudioClip attackBlockDestroyClip;
    public AudioClip lifeblockClip;
    public AudioClip lifeblockDestroyClip;

    //Methods:
    public void PlayJump() {
        if (jumpClip == null) return;
        source.PlayOneShot(jumpClip);
    }

    public void PlayCrouch() {
        if (crouchClip == null) return;
        source.PlayOneShot(crouchClip);
    }

    public void PlayAttack() {
        if (attackClip == null) return;
        source.PlayOneShot(attackClip);
    }

    public void PlayHit() {
        if (hitClip == null) return;
        source.PlayOneShot(hitClip);
    }

    public void PlayJumpBlock() {
        if (jumpBlockClip == null) return;
        source.PlayOneShot(jumpBlockClip);
    }

    public void PlayCrouchBlock() {
        if (crouchBlockClip == null) return;
        source.PlayOneShot(crouchBlockClip);
    }

    public void PlayAttackBlock() {
        if (attackBlockClip == null) return;
        source.PlayOneShot(attackBlockClip);
    }

    public void PlayAttackBlockDestroy() {
        if (attackBlockDestroyClip == null) return;
        source.PlayOneShot(attackBlockDestroyClip);
    }

    public void PlayLifeBlock() {
        if (lifeblockClip == null) return;
        source.PlayOneShot(lifeblockClip);
    }

    public void PlayLifeBlockDestroy() {
        if (lifeblockDestroyClip == null) return;
        source.PlayOneShot(lifeblockDestroyClip);
    }
}