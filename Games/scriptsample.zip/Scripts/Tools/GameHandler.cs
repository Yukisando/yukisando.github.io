﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameHandler : MonoBehaviour {

    public static float gameSpeed;
    public static float blockSpawnRate;
    public static int score;
    public static int highscore;
    public static int lives = 3;

    public float gameSpeedSet = 10f;
    public float blockSpawnRateSet = 1f;
    public int gameOverScreenDuration = 1;
    public GameObject gameOverScreen;

    bool gameRestarting = false;

    private void Awake() {
        gameSpeed = gameSpeedSet;
        blockSpawnRate = blockSpawnRateSet;
        lives = 3;
        score = 0;
    }

    //Shows gameover screen and resets all variables
    public IEnumerator GameOver(GameObject p) {
        gameOverScreen.SetActive(true);
        Time.timeScale = 0;
        gameRestarting = true;
        yield return new WaitForSecondsRealtime(gameOverScreenDuration);
        gameRestarting = false;
        gameOverScreen.SetActive(false);
        SceneManager.LoadScene("Game");
        Time.timeScale = 1;
    }

    //Updates the score
    private void Update() {
        if (!gameRestarting) score += 1;
        else score = 0;
    }

    //Called when the player dies
    public void SetScore() {
        if (score > highscore) {
            highscore = score;
            PlayerPrefs.SetInt("highscore", highscore);
        }
    }

    //Resets the score on button click
    public void ResetScore() {
        highscore = 0;
        PlayerPrefs.SetInt("highscore", 0);
    }

    public void GoToMainMenu() => SceneManager.LoadScene("Menu");
}