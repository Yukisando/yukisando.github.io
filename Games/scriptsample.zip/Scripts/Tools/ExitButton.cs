using UnityEngine;
using UnityEngine.SceneManagement;

public class ExitButton : MonoBehaviour {
    public void ExitGame() => Application.Quit();
}