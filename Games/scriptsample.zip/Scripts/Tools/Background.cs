﻿using UnityEngine;
using UnityEngine.UI;

public class Background : MonoBehaviour {
    private const float extraScrollSpeed = .005f;
    RawImage background;
    public float scrollSpeed = .3f;

    void Awake() => background = GetComponent<RawImage>();

    // Update is called once per frame
    void Update() => background.uvRect = new Rect(background.uvRect.x + (Time.deltaTime * scrollSpeed),
        background.uvRect.y,
        background.uvRect.width,
        background.uvRect.height);

    void LateUpdate() => scrollSpeed += Time.deltaTime * extraScrollSpeed;

}