﻿using UnityEngine;

public class Assets : MonoBehaviour {
    public static Assets i;


    // Makes sure only one instance exists and prevents deletion between scenes
    private void Awake() {
        if(i != null && i != this) DestroyImmediate(this);
        else i = this;

        DontDestroyOnLoad(this);
    }

    //Refs:


}
