﻿using UnityEngine;
using UnityEngine.UI;

public class Ground : MonoBehaviour {
    private const float extraScrollSpeed = .005f;
    RawImage groundBackground;
    public float scrollSpeed = .3f;

    void Awake() => groundBackground = GetComponent<RawImage>();

    void Update() => groundBackground.uvRect = new Rect(groundBackground.uvRect.x + (Time.deltaTime * scrollSpeed),
        groundBackground.uvRect.y,
        groundBackground.uvRect.width,
        groundBackground.uvRect.height);

    void LateUpdate() => scrollSpeed += Time.deltaTime * extraScrollSpeed;
}