﻿using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Score : MonoBehaviour {

    TextMeshProUGUI scoreLabel;

    // Start is called before the first frame update
    void Awake() {
        scoreLabel = GetComponent<TextMeshProUGUI>();
        if (SceneManager.GetActiveScene().name == "Menu") scoreLabel.text = "Best: " + GameHandler.highscore.ToString();
        else scoreLabel.text = "0";
        PlayerPrefs.GetInt("highscore");
    }

    // Update is called once per frame
    void LateUpdate() {
        if (SceneManager.GetActiveScene().name == "Menu") {
            scoreLabel.text = "Best: " + GameHandler.highscore.ToString();
            return;
        }
        scoreLabel.text = GameHandler.score.ToString();
        if (GameHandler.score > GameHandler.highscore) scoreLabel.color = Color.yellow;
    }
}