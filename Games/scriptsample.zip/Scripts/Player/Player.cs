﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour {
    public bool jumpPressed, crouchPressed, attackPressed;
    public LayerMask groundLayerMask, attackBlockLayerMask;
    public BoxCollider2D crouchingCollider;
    public PolygonCollider2D standingCollider;
    public Transform attackTransform;
    public GameObject attackParticleEffectPrefab;
    public GameObject crouchEffectPrefab;
    public Animator camAnimator;

    [Header("Abilities")]
    public float attackRange;
    public float groundCheckRange = .2f;
    public float jumpForce = 15f;
    public float crouchingTime = 1f;
    public float startTimeBtwAttack = 1f;
    float timeBtwAttack;

    Rigidbody2D rigidBody;
    Animator animator;
    SpriteRenderer sr;
    GameHandler gh;

    Vector2 startPosition;
    bool crouching = false;
    bool invinsibility = false;

    //Mobile:
    [HideInInspector] public bool swipeLeft, swipeRight, swipeDown, swipeUp;

    private void Awake() {
        rigidBody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        gh = GetComponentInParent<GameHandler>();
        sr = GetComponent<SpriteRenderer>();
        animator.SetBool("Dead", false);
        startPosition = transform.position;
        if (SceneManager.GetActiveScene().name == "Game") GetComponent<PlayerAI>().enabled = false;
        if (SceneManager.GetActiveScene().name == "Menu") {
            Debug.Log("AI enabled");
            invinsibility = true;
            GetComponent<PlayerAI>().enabled = true;
        }
    }

    private void OnBecameInvisible() => transform.position = startPosition;

    private void OnTriggerEnter2D(Collider2D coll) {
        //Gets hit if hitting an obstacle block and dies if out of lives
        if (coll.transform.tag == "Obstacle") {
            GameAssets.i.PlayHit();
            if (GameHandler.lives <= 0) {
                animator.SetBool("Dead", true);
                gh.SetScore();
                StartCoroutine(gh.GameOver(this.gameObject));
            } else {
                GameAssets.i.PlayHit();
                if (!invinsibility) GameHandler.lives--;
                StartCoroutine(Hit());
            }
        }
        //Gets an extra life if hit by a lifeBlock
        if (coll.transform.tag == "Life" && GameHandler.lives < 3) {
            GameHandler.lives++;
        }
    }

    //All physics and input methods
    private void FixedUpdate() {
        InputHandler();
        MoveHandler();
        AttackHandler();
    }

    //Checks for Input
    void InputHandler() {
        jumpPressed = (Input.GetKeyDown(KeyCode.UpArrow) || swipeUp);
        crouchPressed = (Input.GetKeyDown(KeyCode.DownArrow) || swipeDown);
        attackPressed = (Input.GetKeyDown(KeyCode.RightArrow) || swipeRight);
    }

    void MoveHandler() {
        //Checks if the player is touching the ground
        bool onGround = (Physics2D.OverlapCircle(transform.position, groundCheckRange, groundLayerMask) != null);

        //If not, play the inAir animation
        if (!onGround && !animator.GetBool("Attacking")) animator.SetBool("InAir", true);
        else animator.SetBool("InAir", false);

        //Jumps if touching the ground
        if (jumpPressed && onGround) {
            Vector2 jumpVelocity = new Vector2(0, jumpForce);
            rigidBody.velocity = jumpVelocity;
            if (!animator.GetBool("InAir")) GameAssets.i.PlayJump();
        }

        //Crouches if touching the ground
        if (crouchPressed && onGround && !crouching) {
            StartCoroutine(Crouch());
        }
    }

    void AttackHandler() {
        //If you can attack
        if (attackPressed && timeBtwAttack <= 0) {
            timeBtwAttack = startTimeBtwAttack;

            //Visuals
            if (!animator.GetBool("Dead")) animator.SetBool("Attacking", true);
            GameAssets.i.PlayAttack();
            GameObject attackParticleEffect = Instantiate(attackParticleEffectPrefab, attackTransform.position, Quaternion.identity);

            //Effect
            Collider2D[] attackBlocks = Physics2D.OverlapCircleAll(attackTransform.position, attackRange, attackBlockLayerMask);
            if (attackBlocks != null) {
                //Visuals
                StartCoroutine(Attack(attackParticleEffect));
            }
        } else {
            timeBtwAttack -= Time.fixedDeltaTime;
        }
    }

    IEnumerator Crouch() {
        crouching = true;
        crouchingCollider.enabled = true;
        standingCollider.enabled = false;
        GameAssets.i.PlayCrouch();
        animator.SetBool("Crouching", true);
        Instantiate(crouchEffectPrefab, transform.position, Quaternion.identity);
        yield return new WaitForSecondsRealtime(crouchingTime);
        crouching = false;
        standingCollider.enabled = true;
        crouchingCollider.enabled = false;
        animator.SetBool("Crouching", false);
    }

    IEnumerator Attack(GameObject attackParticleEffect) {
        //As long as the effect exists, destroy attackblock
        while (attackParticleEffect) {
            Collider2D[] attackBlocks = Physics2D.OverlapCircleAll(attackTransform.position, attackRange, attackBlockLayerMask);
            foreach (Collider2D attackBlock in attackBlocks) {
                attackBlock.GetComponent<AttackBlock>().Remove();
                GameAssets.i.PlayAttackBlockDestroy();
            }
            yield return null;
        }
        animator.SetBool("Attacking", false);
    }

    //If hit, blink for a while and sets invisibility
    int blinked = 0;
    IEnumerator Hit() {
        while (blinked <= 3) {
            if (camAnimator) camAnimator.SetBool("Hit", true);
            invinsibility = true;
            sr.color = Color.red;
            yield return new WaitForSeconds(.1f);
            sr.color = Color.white;
            yield return new WaitForSeconds(.1f);
            blinked++;
        }
        if (camAnimator) camAnimator.SetBool("Hit", false);
        blinked = 0;
        invinsibility = false;
    }

    //Attack range gizmo
    private void OnDrawGizmosSelected() {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackTransform.position, attackRange);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, groundCheckRange);
    }
}