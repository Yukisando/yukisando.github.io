﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAI : MonoBehaviour {
    public Transform detectorTransform;
    public float detectionRange = 1;
    Player player;
    Collider2D[ ] colls;

    void Awake() => player = GetComponent<Player>();

    private void FixedUpdate() {
        colls = Physics2D.OverlapCircleAll(point: detectorTransform.position, radius: detectionRange);
        foreach (var coll in colls) {
            if (coll.name == "JumpBlock(Clone)") StartCoroutine(AutoJump());
            if (coll.name == "CrouchBlock(Clone)") StartCoroutine(AutoCrouch());
            if (coll.name == "AttackBlock(Clone)") StartCoroutine(AutoAttack());
        }
    }

    private void OnDrawGizmosSelected() {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(detectorTransform.position, detectionRange);
    }

    IEnumerator AutoJump() {
        player.swipeUp = true;
        yield return new WaitForSeconds(.01f);
        player.swipeUp = false;
    }

    IEnumerator AutoAttack() {
        player.swipeRight = true;
        yield return new WaitForSeconds(.01f);
        player.swipeRight = false;
    }

    IEnumerator AutoCrouch() {
        player.swipeDown = true;
        yield return new WaitForSeconds(.01f);
        player.swipeDown = false;
    }
}