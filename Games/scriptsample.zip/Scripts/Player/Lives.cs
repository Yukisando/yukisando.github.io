﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Lives : MonoBehaviour {
    TextMeshProUGUI livesLabel;

    // Start is called before the first frame update
    void Awake() {
        livesLabel = GetComponent<TextMeshProUGUI>();
        livesLabel.text = "x-";
    }

    // Update is called once per frame
    void LateUpdate() {
        livesLabel.text = "x" + GameHandler.lives.ToString();
    }
}