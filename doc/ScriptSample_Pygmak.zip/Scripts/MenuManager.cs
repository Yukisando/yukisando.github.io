﻿using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Advertisements;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{

    [Header("Upgrades:")]
    public int cannonSkin1Cost = 30000;
    public TextMeshProUGUI cannonSkin1CostText;
    public GameObject cannonSkin1Lock;
    public int cannonSkin2Cost = 60000;
    public TextMeshProUGUI cannonSkin2CostText;
    public GameObject cannonSkin2Lock;
    public TextMeshProUGUI cpsText;
    public TextMeshProUGUI highscoreText;

    [Header("Panels:")]
    public GameObject popupInfo;
    public GameObject turretBuy;

    public int turretCost = 8000;
    public TextMeshProUGUI turretDamage;
    public int turretDamageCost = 10000;
    public TextMeshProUGUI turretDamageCostText;

    [Header("Info:")] public TextMeshProUGUI turretFireRate;
    public int turretFireRateCost = 10000;
    public TextMeshProUGUI turretFireRateCostText;
    public GameObject turretLock;

    private void Awake()
    {
        //Android specific
        Application.targetFrameRate = 300;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
    }

    private void Start()
    {
        Time.timeScale = 1;

        StartCoroutine(UpdateUI());
    }

    private void LateUpdate()
    {
        AndroidSettings();
    }

    private static void AndroidSettings()
    {
        if (Application.platform != RuntimePlatform.Android) return;

        if (Input.GetKey(KeyCode.Escape)) Application.Unload();
    }

    private IEnumerator UpdateUI()
    {
        while (true)
        {
            //Sets all the string to their saved settings
            cpsText.text = PlayerPrefs.GetInt("cps").ToString("n0");
            turretDamage.text = Turret.GetDamage().ToString();
            turretFireRate.text = Turret.GetFireRate().ToString("F3");
            turretFireRateCostText.text = turretFireRateCost.ToString("n0") + " CP";
            turretDamageCostText.text = turretDamageCost.ToString("n0") + " CP";
            cannonSkin1CostText.text = cannonSkin1Cost.ToString("n0") + " HS";
            cannonSkin2CostText.text = cannonSkin2Cost.ToString("n0") + " HS";

            highscoreText.text = "Best: " + PlayerPrefs.GetInt("highscore");

            if (PlayerPrefs.GetInt("turret") >= 1)
            {
                turretBuy.SetActive(false);
                turretLock.SetActive(false);
            }
            else
            {
                turretBuy.SetActive(true);
                turretLock.SetActive(true);
            }

            cannonSkin1Lock.SetActive(PlayerPrefs.GetInt("cannonSkin1") < 1);
            cannonSkin2Lock.SetActive(PlayerPrefs.GetInt("cannonSkin2") < 1);
            yield return new WaitForSeconds(.3f);
        }
    }

    //Goes to the Endless scene
    public void StartEndless()
    {
        SceneFader.Current.Fade(1);
    }

    //Goes to the StartCity_Night beta scene
    public void StartDemo()
    {
        if (SceneManager.sceneCountInBuildSettings >= 2)
            SceneFader.Current.Fade(2);
    }

    //Goes to the upcoming StartCity scene
    public void StartStory()
    {
        popupInfo.SetActive(true);
        popupInfo.GetComponent<Popup>().popupText.text = "Coming soon!";
    }

    //Mainly for debug purposes, it will have it's own section in the settings
    public void ResetScore()
    {
        PlayerPrefs.SetInt("highscore", 0);
        highscoreText.text = "Best: 0";
        PlayerPrefs.SetInt("cps", 0);
        cpsText.text = "0";
        PlayerPrefs.SetInt("turret", 0);
        PlayerPrefs.SetInt("turretDamage", 0);
        PlayerPrefs.SetInt("turretFireRate", 0);
    }

    // ReSharper disable once InconsistentNaming
    public void GiveCPS()
    {
//        if (AdManager.IsWebgl) return;
//        if (Advertisement.IsReady("video"))
//            Advertisement.Show("video");

        PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") + 300);
    }

    //Upgrade Screen
    public void UnlockCannonSkin1()
    {
        if (PlayerPrefs.GetInt("cannonSkin1") == 1)
        {
            //Set skin
        }

        if (PlayerPrefs.GetInt("highscore") > cannonSkin1Cost)
        {
            PlayerPrefs.SetInt("cannonSkin1", 1);
        }
        else
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get a highscore of " + cannonSkin1Cost;
        }
    }

    public void QuitGame() => Application.Unload();

    //Unlock the different permanent upgrades and skins
    public void UnlockCannonSkin2()
    {
        if (PlayerPrefs.GetInt("cannonSkin2") == 1)
        {
            //Set skin
        }

        if (PlayerPrefs.GetInt("highscore") > cannonSkin2Cost)
        {
            PlayerPrefs.SetInt("cannonSkin2", 1);
        }
        else
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get a highscore of " + cannonSkin2Cost;
        }
    }

    public void UnlockTurret()
    {
        if (PlayerPrefs.GetInt("cps") > turretCost)
        {
            PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") - turretCost);
            PlayerPrefs.SetInt("turret", 1);
        }
        else
        {
            var amount = turretCost - PlayerPrefs.GetInt("cps");
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get " + amount + " more Crate Parts!";
        }
    }

    public void UpgradeTurretDamage()
    {
        if (PlayerPrefs.GetInt("turret") != 1)
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Requires 'Turret'";
            return;
        }

        if (PlayerPrefs.GetInt("cps") >= turretDamageCost)
        {
            PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") - turretDamageCost);
            PlayerPrefs.SetInt("turretDamage", PlayerPrefs.GetInt("turretDamage") + 1);
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Turret damage +" + PlayerPrefs.GetInt("turretDamage");
        }
        else
        {
            var amountDue = turretDamageCost - PlayerPrefs.GetInt("cps");
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get " + amountDue + " more Crate Parts!";
        }
    }

    public void UpgradeTurretFireRate()
    {
        if (PlayerPrefs.GetInt("turret") != 1)
        {
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Requires 'Turret'";
            return;
        }

        if (PlayerPrefs.GetInt("cps") >= turretFireRateCost)
        {
            PlayerPrefs.SetInt("cps", PlayerPrefs.GetInt("cps") - turretFireRateCost);
            PlayerPrefs.SetInt("turretFireRate", PlayerPrefs.GetInt("turretFireRate") + 1);
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Turret firerate +" + PlayerPrefs.GetInt("turretFireRate");
        }
        else
        {
            var amountDue = turretFireRateCost - PlayerPrefs.GetInt("cps");
            popupInfo.SetActive(true);
            popupInfo.GetComponent<Popup>().popupText.text = "Get " + amountDue + " more Crate Parts!";
        }
    }

}