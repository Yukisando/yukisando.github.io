﻿using MEC;
using UnityEngine;

public class CratePart : MonoBehaviour
{

#pragma warning disable 0649

    private Rigidbody2D _rb;
    private ItemCatcher _itemCatcher;
    private MeshRenderer _meshRenderer;
    private Vector3 _fullScale;
    private CoroutineHandle _suckCoroutine;

    [SerializeField] [Range(0.0f, 1f)] private float speed = 0.5f;
    [SerializeField] private Texture normal, health;

    private Vector3 _target;
    private bool _isHealth;

    private void Awake()
    {
        _target = GameObject.FindGameObjectWithTag("ItemCatcher").transform.position;
        _itemCatcher = FindObjectOfType<ItemCatcher>();
        _meshRenderer = GetComponent<MeshRenderer>();
        _rb = GetComponent<Rigidbody2D>();

        gameObject.SetActive(false);
        _fullScale = transform.localScale;
    }

    private void OnEnable()
    {
        Reset();
        _rb.gravityScale = 0;
        _rb.velocity = Vector3.zero;
        LeanTween.move(gameObject, _target, speed).setEase(LeanTweenType.easeInSine).setOnComplete(Remove);
    }

    private void Update()
    {
        if (!transform.localScale.Equals(_fullScale)) Grow();
    }

    private void Grow()
    {
        if (transform.localScale.x < _fullScale.x)
        {
            transform.localScale += .01f * Vector3.one;
        }
        else
        {
            transform.localScale = _fullScale;
            _rb.gravityScale = 0;
            _rb.velocity = Vector3.zero;
        }
    }

    private void Remove()
    {
        _itemCatcher.Add();
        gameObject.SetActive(false);
    }

    private void Reset()
    {
        _rb.velocity = Vector3.zero;
        _rb.gravityScale = 2;
        _rb.mass = 3;
        transform.localScale = Vector3.zero;
    }

    public void SetAsHealth()
    {
        _meshRenderer.material.mainTexture = health;
        _rb.mass = 2;
    }

    private void OnDisable()
    {
        Timing.KillCoroutines(_suckCoroutine);
        _meshRenderer.material.mainTexture = normal;
    }

}