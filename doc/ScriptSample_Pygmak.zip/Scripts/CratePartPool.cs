﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CratePartPool : MonoBehaviour
{

#pragma warning disable 0649

    public static CratePartPool Current;

    [SerializeField] private CratePart cratePartPrefab;

    private List<CratePart> _pool = new List<CratePart>();

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
    }

    private void Start()
    {
        //Pre-warms
        AddCratePart(50);
    }

    private void AddCratePart(int _amount)
    {
        for (var i = 0; i < _amount; i++)
        {
            var newCratePart = Instantiate(cratePartPrefab, GameManager.Current.items).GetComponent<CratePart>();
            newCratePart.gameObject.SetActive(false);
            _pool.Add(newCratePart);
        }
    }

    public CratePart Get(bool _isHealth)
    {
        if (_pool.Count == 0) AddCratePart(30);

        foreach (var cp in _pool.Where(_cp => !_cp.gameObject.activeSelf))
        {
            if (_isHealth) cp.SetAsHealth();
            return cp;
        }


        //No available balls were found, extending the pool and returning the first
        var cpFromExtendedPool = Instantiate(cratePartPrefab, GameManager.Current.balls);
        cpFromExtendedPool.gameObject.SetActive(false);
        _pool.Add(cpFromExtendedPool);

        AddCratePart(30);

        if (_isHealth) cpFromExtendedPool.SetAsHealth();
        return cpFromExtendedPool;
    }
}