﻿using System.Collections.Generic;
using UnityEngine;

public class Assets : MonoBehaviour
{

    //Singleton:
    public static Assets Current;

    [Header("Upgrades")]
    public Sprite burstSprite;
    public Sprite powerSprite;
    public Sprite firerateSprite;
    public Sprite sizeSprite;
    public Sprite freezeSprite;
    public Sprite damageSprite;
    public Sprite bounceSprite;
    public Sprite electricSprite;
    public Sprite blazeSprite;

    //Collection of assets for easy access
    [Header("Particles")]
    public GameObject ballTouch;
    public GameObject crateBreak;

    [Header("Items")]
    public GameObject electricTouch;
    public GameObject fireTouch;
    public GameObject freezeTouch;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
    }

    public List<Sprite> GetUpgradeSprites()
    {
        var spriteList = new List<Sprite>
        {
            burstSprite,
            powerSprite,
            firerateSprite,
            sizeSprite,
            freezeSprite,
            damageSprite,
            bounceSprite,
            electricSprite,
            blazeSprite
        };

        return spriteList;
    }

}