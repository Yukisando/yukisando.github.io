﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using MEC;
using UnityEngine;

public class CrateSpawner : MonoBehaviour
{
    //Singleton:
    public static CrateSpawner Current;

    [Header("Assignments")]
    public Crate crate;

    public int crateAmount = 5;
    public int crateAmountIncrease = 3;
    public int crateHealth = 10;
    public int crateHealthIncrease = 3;
    private List<Crate> _cratePool = new List<Crate>();

    [SerializeField]
    public int currentCrateCount;

    [SerializeField]
    public float initialForce = .1f;
    public float initialForceIncrease = .1f;

    [Header("Waves")]
    public bool spawnAtStart;

    private int _spawnedCrateCount;
    public float spawnerSize = 2.8f;
    public float spawnRate = 1f;
    private bool _waveEnded;
    public int waveNumber = 1;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);

        //Pre-warms some crates
        CreateCrates(150);
    }

    private void CreateCrates(int _amount)
    {
        for (var i = 0; i < _amount; i++)
        {
            //The position of the current spawn
            var xPos = Random.Range(-spawnerSize, spawnerSize);
            var spawnPosition = new Vector3(transform.position.x + xPos, transform.position.y, transform.position.z);

            //Create a new Crate (Eventually enable from a pool of crates)
            var newCrate = Instantiate(crate, spawnPosition, Quaternion.Euler(0.0f, 0.0f, Random.Range(0.0f, 360.0f)), GameManager.Current.crates);
            _cratePool.Add(newCrate);
        }
    }

    private Crate GetCrate()
    {
        //In case for some reason the pool
        if (_cratePool.Count == 0)
        {
            Debug.LogError("Pool was not pre-warmed! Creating balls...");
            CreateCrates(50);
        }

        //Finds an inactive ball and returns it
        foreach (var thisCrate in _cratePool.Where(_crate => !_crate.gameObject.activeSelf))
        {
            return thisCrate;
        }

        //No available crates were found, extending the pool and returning the first
        var crateFromExtendedPool = Instantiate(crate, GameManager.Current.crates);
        crateFromExtendedPool.gameObject.SetActive(false);
        _cratePool.Add(crateFromExtendedPool);

        CreateCrates(9);

        return crateFromExtendedPool;
    }

    private void Start()
    {
        if (spawnAtStart) Timing.RunCoroutine(Spawner(crateAmount));
    }

    //The spawning coroutine Garbage collection starts to slow down the game on old devices on wave 30
    private IEnumerator<float> Spawner(int _waveAmount)
    {
        while (_spawnedCrateCount < _waveAmount)
        {
            var currentCrate = GetCrate();
            currentCrate.Reset();
            yield return Timing.WaitForSeconds(1 / spawnRate);
            currentCrate.gameObject.SetActive(true);
            _spawnedCrateCount++;
        }

        _waveEnded = true;
    }

    private void Update()
    {
        //Waits for all crates to be destroyed before spawning next wave
        if (_waveEnded && currentCrateCount == 0 && !GameManager.Current.upgradeScreen.activeSelf) GameManager.Current.ShowUpgrades();
    }

    public void SpawnNextWave()
    {
        //Stop game when reaching the wave number of the level
        if (waveNumber == GameManager.Current.waveSize && !GameManager.Current.endless)
        {
            GameManager.Current.EndGame();
            return;
        }

        //Increases the number of crates
        crateAmount += crateAmountIncrease;

        //Increase the init speed of the crates
        initialForce += initialForceIncrease;
        spawnRate += .1f;
        waveNumber++;

        //Every multiple of 3, each crates gains some health
        if (waveNumber % 3 == 0) crateHealth += crateHealthIncrease;
        _waveEnded = false;
        _spawnedCrateCount = 0;
        Timing.RunCoroutine(Spawner(crateAmount).CancelWith(gameObject));
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawRay(transform.position, transform.right * spawnerSize);
        Gizmos.DrawRay(transform.position, transform.right * -spawnerSize);
    }
}