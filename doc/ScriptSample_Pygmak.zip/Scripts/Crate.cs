﻿using System.Collections;
using System.Linq;
using MEC;
using UnityEngine;

public class Crate : MonoBehaviour
{

#pragma warning disable 0649

    public GameObject burningOverlay, frozenOverlay, electricOverlay, damagedOverlay;

    [SerializeField]
    private int health = 10;
    public GameObject damagePopupPrefab;
    public Sprite[] sprites;

    private bool _init = true;
    private bool _isFrozen, _isBurning, _isElectrified;
    private Rigidbody2D _rb;

    private SpriteRenderer _sr;
    private int _startHealth = 10;
    private Vector3 _initPosition;
    private Vector3 _initScale;

    private void Awake()
    {
        _sr = GetComponent<SpriteRenderer>();
        _rb = GetComponent<Rigidbody2D>();

        //Chooses a random sprite
        _sr.sprite = sprites[Random.Range(0, sprites.Length)];
        _initPosition = transform.position;
        _initScale = transform.localScale;

        gameObject.SetActive(false);
    }

    public void Reset()
    {
        electricOverlay.SetActive(false);
        burningOverlay.SetActive(false);
        frozenOverlay.SetActive(false);
        _rb.velocity = Vector2.zero;
        _rb.AddForce(Vector3.down * CrateSpawner.Current.initialForce, ForceMode2D.Impulse);
    }

    private void OnEnable()
    {
        transform.position = _initPosition;
        transform.localScale = _initScale;
        health = CrateSpawner.Current.crateHealth;
        _startHealth = health;

        _isFrozen = false;
        _isElectrified = false;
        _isBurning = false;

        burningOverlay.SetActive(false);
        frozenOverlay.SetActive(false);
        electricOverlay.SetActive(false);

        //Sets a random size
        transform.localScale *= Random.Range(0.5f, 1.1f);
        CrateSpawner.Current.currentCrateCount++;
    }

    private void OnDisable()
    {
        StopAllCoroutines();
        if (!_init)
            CrateSpawner.Current.currentCrateCount--;
        _init = false;
    }

    private void Hit()
    {
        GameManager.Current.score += 2;
        health -= Cannon.Current.damage;
        transform.localScale -= transform.localScale / 20;
        AudioManager.Current.PlayCrateHit();

        //Destroys the crate if it gets too small (For gameplay reasons, and adds an element of randomness to the difficulty)
        if (transform.localScale.x <= .35f) health = 0;
        if (health <= 0) Remove();

        //Sets the broken sprite overlay at half life
        if (health < _startHealth / 2 && !damagedOverlay.activeSelf) damagedOverlay.SetActive(true);
    }

    private void Remove()
    {
        AudioManager.Current.PlayCrateBreak();
        Instantiate(Assets.Current.crateBreak, transform.position, Quaternion.identity, GameManager.Current.particles);

        float amountOfCrateParts = Random.Range(2, 6);
        Timing.CallPeriodically(.5f, .5f / amountOfCrateParts, SpawnCrateParts);

        damagedOverlay.SetActive(false);
        gameObject.SetActive(false);
    }

    private void SpawnCrateParts()
    {
        var cp = CratePartPool.Current.Get(false);
        cp.transform.position = transform.position += (Vector3) Random.insideUnitCircle * .6f;
        cp.transform.rotation = Random.rotation;
        cp.gameObject.SetActive(true);
    }

    //Freezes the rigidbody on the object for a short time
    //Crates move also slower after being frozen
    private IEnumerator Frozen()
    {
        frozenOverlay.SetActive(true);
        _isFrozen = true;
        _rb.velocity /= 5;
        yield return new WaitForSeconds(.8f + Cannon.Current.freeze / 5f);
        _isFrozen = false;
        frozenOverlay.SetActive(false);
    }

    //Generate AOE damage to all crates in the blast radius
    private IEnumerator Electrified()
    {
        electricOverlay.SetActive(true);
        _isElectrified = true;
        yield return new WaitForSeconds(.2f);
        electricOverlay.SetActive(false);
        var objInRadius = Physics2D.OverlapCircleAll(transform.position, 1.5f + Cannon.Current.electrify / 8f);
        foreach (var currentCrate in objInRadius.Where(_currentCrate => _currentCrate.GetComponent<Crate>() != null))
        {
            if (currentCrate.gameObject == gameObject) continue;
            var crate = currentCrate.GetComponent<Crate>();
            crate.health -= 3 + Cannon.Current.electrify;
            crate.Hit();
        }

        _isElectrified = false;
    }

    //Adds an immediate burn damage and slow DOT
    private IEnumerator Burning()
    {
        burningOverlay.SetActive(true);
        _isBurning = true;
        yield return new WaitForSeconds(.4f);
        health--;
        if (health <= 0) Remove();
        yield return new WaitForSeconds(.4f);
        health -= Cannon.Current.blaze;
        if (health <= 0) Remove();
        _isBurning = false;
        burningOverlay.SetActive(false);
    }

    //Visual feedback from effects
    public void CollidedWithBall(MonoBehaviour _ball)
    {
        switch (_ball.tag)
        {
            default:
                Hit();
                break;
            case "FrozenBall":
                Hit();
                GameManager.Current.score += 2;
                transform.localScale -= transform.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                if (gameObject.activeSelf && !_isFrozen && !_isBurning && !_isElectrified) StartCoroutine(Frozen());
                break;

            case "ElectricBall":
                Hit();
                GameManager.Current.score += 2;
                transform.localScale -= transform.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                if (gameObject.activeSelf && !_isElectrified && !_isBurning && !_isFrozen) StartCoroutine(Electrified());
                break;

            case "FireBall":
                Hit();
                GameManager.Current.score += 2;
                transform.localScale -= transform.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                if (gameObject.activeSelf && !_isFrozen && !_isBurning && !_isElectrified) StartCoroutine(Burning());
                break;

            case "SideBall":
                Hit();
                GameManager.Current.score++;
                health -= 2 + CrateSpawner.Current.waveNumber / 4;
                transform.localScale -= transform.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                break;

            case "TurretBall":
                Hit();
                GameManager.Current.score++;
                health -= Turret.GetDamage();
                transform.localScale -= transform.localScale / 25;
                AudioManager.Current.PlayCrateHit();
                break;
        }

        if (health <= 0) Remove();
    }

    private void OnTriggerEnter2D(Collider2D _other)
    {
        //Deals damage if the crates hits the bottom
        if (_other.CompareTag("Deadzone"))
        {
            GameManager.Current.DealDamageToPlayer(health);
            AudioManager.Current.PlayCrateFail();

            //Damage popup visual!
            var healthPopup = Instantiate(damagePopupPrefab, Vector3.zero, Quaternion.identity, GameManager.Current.particles).GetComponent<DamagePopup>();
            healthPopup.SetPosition(transform.position);
            healthPopup.SetHealthLossText(health.ToString());
            gameObject.SetActive(false);
        }

        //Piercing system implemented but not yet in use
        if (_other.CompareTag("TurretBall"))
        {
            GameManager.Current.score++;
            health -= Turret.GetDamage();
            transform.localScale -= transform.localScale / 25;
            AudioManager.Current.PlayCrateHit();
        }
    }

    private void OnBecameInvisible()
    {
        gameObject.SetActive(false);
    }

    private void OnDrawGizmos()
    {
        if (!_isElectrified) return;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, 2f);
    }

}