using UnityEngine;
using UnityEngine.SceneManagement;

public class AudioManager : MonoBehaviour
{

#pragma warning disable 0649

    //Singleton
    public static AudioManager Current;

    [SerializeField] private AudioClip shootClip;
    [SerializeField] private AudioClip wallHitClip;
    [SerializeField] private AudioClip[] crateBreakClips;
    [SerializeField] private AudioClip crateBlazeHitClip;
    [SerializeField] private AudioClip crateElectricHitClip;
    [SerializeField] private AudioClip crateFrozenHitClip;
    [SerializeField] private AudioClip crateFailClip;
    [SerializeField] private AudioClip[] crateHitClips;

    //UI
    [SerializeField] private AudioClip hoverItemClip;
    [SerializeField] private AudioClip pickupClip;
    [SerializeField] private AudioClip selectItemClip;

    private AudioSource _mainSource;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);

        _mainSource = GetComponent<AudioSource>();
    }

    private void Start()
    {
        if (_mainSource == null) return;

        if (SceneManager.GetActiveScene().buildIndex == 0)
        {
            _mainSource.Play();
            _mainSource.loop = true;
        }
        else
        {
            _mainSource.loop = false;
        }
    }

    //Shoot implement pooling system!
    public void PlayShoot()
    {
        _mainSource.pitch = Random.Range(.3f, .6f);
        _mainSource.PlayOneShot(shootClip);
    }

    public void PlayCrateHit()
    {
        _mainSource.pitch = Random.Range(.3f, .6f);
        _mainSource.PlayOneShot(crateHitClips[Random.Range(0, crateHitClips.Length)]);
    }

    public void PlayFrozenCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateFrozenHitSound = new GameObject("CrateFrozenHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateFrozenHitSound.volume = .5f;
        crateFrozenHitSound.pitch += Random.Range(-.3f, .3f);
        crateFrozenHitSound.PlayOneShot(crateFrozenHitClip);
        crateFrozenHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateFrozenHitSound.transform.gameObject, 1f);
    }

    public void PlayBlazeCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateBlazeHitSound = new GameObject("CrateBlazeHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateBlazeHitSound.volume = .2f;
        crateBlazeHitSound.pitch += Random.Range(-.3f, .3f);
        crateBlazeHitSound.PlayOneShot(crateBlazeHitClip);
        crateBlazeHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateBlazeHitSound.transform.gameObject, 1f);
    }

    public void PlayElectricCrateHit()
    {
        // Create Gameobject and attach audiosource
        var crateElectricHitSound = new GameObject("CrateElectricHit", typeof(AudioSource)).GetComponent<AudioSource>();
        crateElectricHitSound.volume = .3f;
        crateElectricHitSound.pitch += Random.Range(0f, .3f);
        crateElectricHitSound.PlayOneShot(crateElectricHitClip);
        crateElectricHitSound.transform.parent = GameManager.Current.clips;
        Destroy(crateElectricHitSound.transform.gameObject, 1f);
    }

    public void PlayCrateBreak()
    {
        // Create Gameobject and attach audiosource
        var crateBreakSound = new GameObject("CrateBreak", typeof(AudioSource)).GetComponent<AudioSource>();
        crateBreakSound.volume = .2f;
        crateBreakSound.pitch += Random.Range(-.3f, 0f);
        crateBreakSound.PlayOneShot(crateBreakClips[Random.Range(0, crateBreakClips.Length)]);
        crateBreakSound.transform.parent = GameManager.Current.clips;
        Destroy(crateBreakSound.transform.gameObject, 1f);
    }

    public void PlayCrateFail()
    {
        // Create Gameobject and attach audiosource
        var crateFailSound = new GameObject("CrateFail", typeof(AudioSource)).GetComponent<AudioSource>();
        crateFailSound.pitch += Random.Range(-.3f, .3f);
        crateFailSound.PlayOneShot(crateFailClip);
        crateFailSound.transform.parent = GameManager.Current.clips;
        Destroy(crateFailSound.transform.gameObject, 1f);
    }

    public void PlayHoverClip()
    {
        var hoverSound = new GameObject("Hover", typeof(AudioSource)).GetComponent<AudioSource>();
        DontDestroyOnLoad(hoverSound.gameObject);
        hoverSound.pitch += Random.Range(-.3f, .3f);
        hoverSound.PlayOneShot(hoverItemClip);
        hoverSound.volume = .5f;
        Destroy(hoverSound.transform.gameObject, 1f);
    }

    public void PlaySelectClip()
    {
        var selectSound = new GameObject("Select", typeof(AudioSource)).GetComponent<AudioSource>();
        DontDestroyOnLoad(selectSound.gameObject);
        selectSound.pitch += Random.Range(-.3f, .3f);
        selectSound.PlayOneShot(selectItemClip);
        selectSound.volume = .7f;
        Destroy(selectSound.transform.gameObject, 1f);
    }

    public void PlayPickupClip()
    {
        var pickupSound = new GameObject("Pickup", typeof(AudioSource)).GetComponent<AudioSource>();
        pickupSound.pitch += Random.Range(-.3f, .3f);
        pickupSound.PlayOneShot(pickupClip);
        Destroy(pickupSound.transform.gameObject, 1f);
    }

    public void PlayWallHit()
    {
        if (_mainSource.isPlaying) return;
        
        _mainSource.pitch = Random.Range(.3f, 1.3f);
        _mainSource.PlayOneShot(hoverItemClip);
    }

}