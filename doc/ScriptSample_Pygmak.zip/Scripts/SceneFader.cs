﻿using MEC;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneFader : MonoBehaviour
{

#pragma warning disable 0649

    public static SceneFader Current;

    [SerializeField] private CanvasGroup canvasGroup;
    
    private int _sceneIndexToLoad = -1; //Makes sure you load the scene you want

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);

    }

    private void Start()
    {
        canvasGroup.alpha = 1;
        FadeOut();
    }

    public void Fade(int _sceneIndex)
    {
        _sceneIndexToLoad = _sceneIndex;
        LeanTween.alphaCanvas(canvasGroup, 1, .2f).setOnComplete(LoadScene);
    }

    private void FadeOut()
    {
        LeanTween.alphaCanvas(canvasGroup, 0, .2f);
    }

    private void LoadScene()
    {
        Timing.KillCoroutines();
        SceneManager.LoadScene(_sceneIndexToLoad);
    }

}