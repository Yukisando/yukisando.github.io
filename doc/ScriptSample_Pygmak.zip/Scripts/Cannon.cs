﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Experimental.Rendering.LWRP;

public class Cannon : MonoBehaviour
{

#pragma warning disable 0649

    //Singleton
    public static Cannon Current;

    [SerializeField] private Ball ballPrefab;
    private List<Ball> _ballPool = new List<Ball>();
    private Vector3 _ballZOffset = new Vector3(0, 0, -1);
    private int _shotCount;
    private Light2D _nozzleFlash;

    [Header("Details")] [SerializeField] private Vector3 burstAngleOffset = new Vector3(.1f, 0, 0);
    [SerializeField] private Vector3 burstPositionOffset = new Vector3(.3f, 0, 0);

    [Header("Player")] public int health = 100;
    public int damage = 1;
    public bool dead;

    [Header("Power Ups")] public int freeze;
    public int freezeCap = 15;

    public int electrify;
    public int electrifyCap = 18;

    public int blaze;
    public int blazeCap = 20;

    public float fireRate = 5f;
    public float fireRateCap = 20;

    public int bounceLimit = 1;
    public int bounceLimitCap = 5;

    public float ballSizeIncrease = 0.05f;
    public float sizeCap = .5f;

    public int damageUp = 0;
    public int damageUpCap = 10;

    private int _burstCount;
    public int burst;
    public int burstCap = 4;

    private bool _isShooting;

    public float power = .2f;
    public float powerCap = 1.2f;

    [Header("Assignments")]
    [SerializeField] private Sprite[] sprites;
    [SerializeField] private Transform nozzle;
    [SerializeField] private SpriteRenderer sr;

    private void Awake()
    {
        if (Current == null) Current = this;
        else if (Current != this) Destroy(Current);
        dead = false;

        _nozzleFlash = GetComponentInChildren<Light2D>();
    }

    private void Start()
    {
        //Pre-warms the pool
        CreateBalls(30);
    }

    private void Update()
    {
        ShootHandler();
    }

    private float _shootTimer;

    private void ShootHandler()
    {
        if (GameManager.Current.upgradeScreen.activeSelf || GameManager.Current.gameOverScreen.activeSelf) return;
        _shootTimer += Time.deltaTime;
        if (!(_shootTimer >= 1 / fireRate)) return;
        _shootTimer = 0;
        Shoot();
    }

    private void Shoot()
    {
        //Normal balls
        HandleNormal();

        //Burst Upgrade
        if (burst > 0) HandleBurst();

        //Handles the cannon's visual feedback
        sr.sprite = sprites[1];
        _nozzleFlash.enabled = true;
        Invoke( nameof(CannonBarrelReset), .1f);
    }

    private void HandleNormal()
    {
        var currentBall = GetBall();
        currentBall.SetAsNormal();

        _shotCount++;

        //Handles the frequency of the status balls and grantees no overlap
        if (freeze > 0 && _shotCount % 3 == 0) currentBall.tag = "FrozenBall";
        if (blaze > 0 && _shotCount % 2 == 0) currentBall.tag = "FireBall";
        if (electrify > 0 && _shotCount % 5 == 0) currentBall.tag = "ElectricBall";

        currentBall.transform.position = nozzle.position;
        currentBall.gameObject.SetActive(true);
        currentBall.rigidBody.AddForce(transform.up * power, ForceMode2D.Impulse);

        AudioManager.Current.PlayShoot();
    }

    private void HandleBurst()
    {
        if (burst <= 0) return;
        
        _burstCount++;
        var nozzlePosition = nozzle.position;
        var nozzleDirection = transform.up;
        if (burst >= 5)
        {
            ShotGun(nozzlePosition, nozzleDirection, 1);
        }else if (_burstCount % (burst - 5) == 0)
        {
            ShotGun(nozzlePosition, nozzleDirection, 1);
        }
        
    }

    private void ShotGun(Vector3 _nozzlePosition, Vector3 _direction, int _pair)
    {
        var spawnedBallLeft = GetBall();
        spawnedBallLeft.SetAsBurst();
        spawnedBallLeft.transform.position = _nozzlePosition - _ballZOffset - burstPositionOffset;
        spawnedBallLeft.gameObject.SetActive(true);
        spawnedBallLeft.rigidBody.AddForce((_direction + burstAngleOffset * _pair).normalized * power, ForceMode2D.Impulse);

        var spawnedBallRight = GetBall();
        spawnedBallRight.SetAsBurst();
        spawnedBallRight.transform.position = _nozzlePosition - _ballZOffset + burstPositionOffset;
        spawnedBallRight.gameObject.SetActive(true);
        spawnedBallRight.rigidBody.AddForce((_direction - burstAngleOffset * _pair).normalized * power, ForceMode2D.Impulse);
    }

    //Resets cannon sprite
    private void CannonBarrelReset()
    {
        _nozzleFlash.enabled = false;
        sr.sprite = sprites[0];
    }

    private Ball GetBall()
    {
        //In case for some reason the pool
        if (_ballPool.Count == 0) CreateBalls(10);

        //Finds an inactive ball and returns it
        foreach (var ball in _ballPool.Where(_ball => !_ball.gameObject.activeSelf)) return ball;

        //No available balls were found, extending the pool and returning the first
        var ballFromExtendedPool = Instantiate(ballPrefab, GameManager.Current.balls);
        ballFromExtendedPool.gameObject.SetActive(false);
        _ballPool.Add(ballFromExtendedPool);

        CreateBalls(9);

        return ballFromExtendedPool;
    }

    private void CreateBalls(int _amount)
    {
        for (var i = 0; i < _amount; i++)
        {
            var newBall = Instantiate(ballPrefab, GameManager.Current.balls);
            newBall.gameObject.SetActive(false);
            _ballPool.Add(newBall);
        }
    }

}